function getBaseURL() {
  var elem = document.getElementsByTagName("base")[0];
  if (typeof elem != "undefined" && elem != null) {
    return elem.href;
  }
  return window.location.origin;
}

const iniciarSesion = (e) => {
  const formulario = e.parentElement;
  let correo = formulario.correo.value;
  let password = formulario.password.value;
  sessionStorage.setItem("token", null);
  sessionStorage.setItem("correo", null);
  let token;

  if (correo && password) {
    const url = `http://localhost:9090/api/v1/iniciarsesion?correo=${correo}&password=${password}`;
    const atributos = {
      method: "POST", // or 'PUT'
      headers: { "Content-type": "application/json; charset=UTF-8" },
    };

    fetch(url, atributos)
      .then((response) => response.json())
      .then((responseJson) => {
        if (responseJson.status === 200) {
          token = `Bearer ${responseJson.data}`;
          sessionStorage.setItem("token", token);
          sessionStorage.setItem("correo", correo);
          window.location.href = `${getBaseURL()}/index.html`;
        } else {
          const mensaje = `
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <strong>${responseJson.message}</strong> 
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                `;
          document.querySelector("#mensaje").innerHTML = mensaje;
          formulario.correo.value = "";
          formulario.password.value = "";
        }
      })
      .catch((error) => {
        console.log("Hubo un problema con la petición Fetch:" + error.message);
      });
  }
};

function includeHTML() {
  var z, i, elmnt, file, xhttp;
  /* Loop through a collection of all HTML elements: */
  z = document.getElementsByTagName("*");
  for (i = 0; i < z.length; i++) {
    elmnt = z[i];
    /*search for elements with a certain attribute:*/
    file = elmnt.getAttribute("w3-include-html");
    if (file) {
      /* Make an HTTP request using the attribute value as the file name: */
      xhttp = new XMLHttpRequest();
      xhttp.onreadystatechange = function () {
        if (this.readyState == 4) {
          if (this.status == 200) {
            elmnt.innerHTML = this.responseText;
          }
          if (this.status == 404) {
            elmnt.innerHTML = "Page not found.";
          }
          /* Remove the attribute, and call this function once more: */
          elmnt.removeAttribute("w3-include-html");
          includeHTML();
        }
      };
      xhttp.open("GET", file, true);
      xhttp.send();
      /* Exit the function: */
      return;
    }
  }
}
includeHTML();
