// algunas funciones se repetirán, solamente para claridad del ejemplo
// para no tener dependencia de los demás archivos, ya que este sistema
// no va a seguir creciendo, en caso que se utilice como base
// refactorizar.

const irA = (uri) => {
    window.location.href = `${getBaseURL()}/${uri}`;
}

function getBaseURL(){
    var elem=document.getElementsByTagName("base")[0];
    if (typeof(elem) != 'undefined' && elem != null){
        return elem.href;
    }
    return window.location.origin;
}

const cargaWeb = () => {
    const token = sessionStorage.getItem('token')
    console.log("token: ", token)
    if (token) {
        const correo = sessionStorage.getItem('correo')

        const url = `http://localhost:9090/api/v1/usuarios?correo=${correo}`
        const atributos = {
            method: 'POST', // or 'PUT'
            headers: {
                "Content-type": "application/json; charset=UTF-8",
                "Autorizacion": `${token}`
            }
        }

        fetch(url, atributos)
            .then(response => {
                if (response.status !== 403) {
                    return response.json()
                } else {
                    window.location.href = `${getBaseURL()}/iniciarSesion.html`;
                }
            })
            .then(responseJson => {
                if (responseJson.status === 200) {
                    const usuario = responseJson.data
                    document.querySelector('#nombreUsuario').innerHTML = usuario.nombre
                }
                else {
                    document.querySelector('#nombreUsuario').innerHTML = "Hubo un problema al cargar al usuario"
                }
            })
            .catch(error => {
                console.log('Hubo un problema con la petición Fetch:' + error.message);
            });
    } else {
        window.location.href = `${getBaseURL()}/iniciarSesion.html`;
    }
}

function includeHTML() {
    var z, i, elmnt, file, xhttp;
    /* Loop through a collection of all HTML elements: */
    z = document.getElementsByTagName("*");
    for (i = 0; i < z.length; i++) {
        elmnt = z[i];
        /*search for elements with a certain attribute:*/
        file = elmnt.getAttribute("w3-include-html");
        if (file) {
            /* Make an HTTP request using the attribute value as the file name: */
            xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function () {
                if (this.readyState == 4) {
                    if (this.status == 200) { elmnt.innerHTML = this.responseText; }
                    if (this.status == 404) { elmnt.innerHTML = "Page not found."; }
                    /* Remove the attribute, and call this function once more: */
                    elmnt.removeAttribute("w3-include-html");
                    includeHTML();
                }
            }
            xhttp.open("GET", file, true);
            xhttp.send();
            /* Exit the function: */
            return;
        }
    }
}
includeHTML();