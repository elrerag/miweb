const cargaTabla = () => {
  const token = sessionStorage.getItem("token");
  if (token) {
    const correo = sessionStorage.getItem("correo");
    const url = `http://localhost:9090/api/v1/usuarios`;
    const atributos = {
      method: "GET", // or 'PUT'
      headers: {
        "Content-type": "application/json; charset=UTF-8",
        Autorizacion: `${token}`,
      },
    };
    fetch(url, atributos)
      .then((response) => response.json())
      .then((mi_json) => {
        $("#tabla").DataTable({
          data: mi_json.data.map((x) => [
            x.nombre,
            x.email,
            x.roles.reduce((rol, cadena) => cadena + " " + rol, ""),
          ]),
          language: {
            url:
              "https://cdn.datatables.net/plug-ins/1.10.21/i18n/Spanish.json",
          },
        });
      })
      .catch((error) => {
        console.log("Hubo un problema con la petición Fetch:" + error.message);
      });
  } else {
    window.location.href = `${getBaseURL()}/iniciarSesion.html`;
  }
};

const irA = (uri) => {
  window.location.href = `${getBaseURL()}/${uri}`;
};

function getBaseURL() {
  var elem = document.getElementsByTagName("base")[0];
  if (typeof elem != "undefined" && elem != null) {
    return elem.href;
  }
  return window.location.origin;
}

function includeHTML() {
  var z, i, elmnt, file, xhttp;
  /* Loop through a collection of all HTML elements: */
  z = document.getElementsByTagName("*");
  for (i = 0; i < z.length; i++) {
      elmnt = z[i];
      /*search for elements with a certain attribute:*/
      file = elmnt.getAttribute("w3-include-html");
      if (file) {
          /* Make an HTTP request using the attribute value as the file name: */
          xhttp = new XMLHttpRequest();
          xhttp.onreadystatechange = function () {
              if (this.readyState == 4) {
                  if (this.status == 200) { elmnt.innerHTML = this.responseText; }
                  if (this.status == 404) { elmnt.innerHTML = "Page not found."; }
                  /* Remove the attribute, and call this function once more: */
                  elmnt.removeAttribute("w3-include-html");
                  includeHTML();
              }
          }
          xhttp.open("GET", file, true);
          xhttp.send();
          /* Exit the function: */
          return;
      }
  }
}
includeHTML();
