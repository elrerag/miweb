package cl.lherrera.jwtapp.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.lherrera.jwtapp.model.Usuario;

@Repository
public interface UsuarioDao extends JpaRepository<Usuario, Integer> {
	boolean existsByUsername(String username);

	/**
	 * Ya que mediante el token tenemos la información del nombre de usuario,
	 * utilizamos esta información, para poder obtener al usuario mediante esta
	 * información
	 */
	Optional<Usuario> findByUsername(String username);
}
