package cl.lherrera.jwtapp.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


/**
 * No se utilizará el campo tipo único, ya que el Dialecto falla, no se ha
 * probado con otro motor, de todas formas este contrrol se maneja mediante el
 * método `findByUser`, a nivel de seguriidad.
 * 
 * @author luisherrera
 *
 */
@Entity
public class Usuario {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	Integer id;
	String nombre;
	String apellido;
	@Column(name = "correo")
	String username;
	@Column(name = "contrasenia")
	String password;

	@ElementCollection(fetch = FetchType.EAGER)
	List<Rol> roles;

	public Usuario() {
	}

	public Usuario(Integer id, String nombre, String apellido, String username, String password, List<Rol> roles) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.apellido = apellido;
		this.username = username;
		this.password = password;
		this.roles = roles;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<Rol> getRoles() {
		return roles;
	}

	public void setRoles(List<Rol> roles) {
		this.roles = roles;
	}

	@Override
	public String toString() {
		return "Usuario [id=" + id + ", nombre=" + nombre + ", apellido=" + apellido + ", username=" + username
				+ ", password=" + password + ", roles=" + roles + "]";
	}

}
