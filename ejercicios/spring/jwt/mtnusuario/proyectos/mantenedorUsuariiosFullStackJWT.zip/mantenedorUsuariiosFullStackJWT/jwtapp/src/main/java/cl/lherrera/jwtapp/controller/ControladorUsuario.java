package cl.lherrera.jwtapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cl.lherrera.jwtapp.dto.RespuestaDTO;
import cl.lherrera.jwtapp.dto.UsuarioDTO;
import cl.lherrera.jwtapp.service.ServicioUsuario;

@RestController
@RequestMapping("/api/v1/usuarios")
public class ControladorUsuario {

	@Autowired
	private ServicioUsuario servicioUsuario;

	@GetMapping(path = { "", "/" })
	public RespuestaDTO<List<UsuarioDTO>> listar() {
		RespuestaDTO<List<UsuarioDTO>> respuesta = new RespuestaDTO<>();
		List<UsuarioDTO> usuarios = servicioUsuario.listaDeUsuarios();

		respuesta.setStatus(200);
		respuesta.setData(usuarios);

		return respuesta;
	}

	@PostMapping(path = { "", "/" })
	public RespuestaDTO<UsuarioDTO> encontrarPorNombreDeUsuario(@RequestParam String correo) {
		UsuarioDTO usuario = servicioUsuario.obtenerPorCorreo(correo);
		RespuestaDTO<UsuarioDTO> respuesta = new RespuestaDTO<>();
		respuesta.setStatus(200);
		respuesta.setData(usuario);

		return respuesta;
	}

}
