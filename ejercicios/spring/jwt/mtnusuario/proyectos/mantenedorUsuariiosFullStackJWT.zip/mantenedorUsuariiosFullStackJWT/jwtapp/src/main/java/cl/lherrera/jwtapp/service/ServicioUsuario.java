package cl.lherrera.jwtapp.service;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetailsService;

import cl.lherrera.jwtapp.dto.UsuarioDTO;

/**
 * Al extender UserDetailsService, traemos el método loadUserByUsername, que
 * sobre escribimos en la implementación, podremos ver que a veces se implementa
 * un implements UserDetailsService, pero esto causa confusiones ya que a veces
 * los desarrolladores que no conocen que este método está en
 * UserDetailsService, lo ponen igual acá, en this. y lo sobre escriben en la
 * implementación, funcionando de todas formas por que Spring asume sobre
 * escrito el loadUserByUsername que le pertenece a UserDetailsService y no
 * ServicioUsuario.
 *
 */
public interface ServicioUsuario extends UserDetailsService {

	String iniciarSesion(String correo, String contrasenia);

	List<UsuarioDTO> listaDeUsuarios();

	/**
	 * Servicio encargado de registrar un usuario hay que tener en cuenta varias
	 * cosas como el dar una buena encriptación a la base de datos.
	 */
	String registraNuevoUsuario(UsuarioDTO usuarioDTO);
	
	/**
	 * A diferencia del método loadUserByUsername, este no retorna
	 * un UserDetails, si no que retorna un DTO para efectos
	 * de poder mostrar más detalles del usuario que se consulte.
	 */
	UsuarioDTO obtenerPorCorreo(String correo);

}
