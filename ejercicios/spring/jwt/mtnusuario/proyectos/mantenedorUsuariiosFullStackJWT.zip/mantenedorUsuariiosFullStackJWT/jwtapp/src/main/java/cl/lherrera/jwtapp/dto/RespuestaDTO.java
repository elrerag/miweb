package cl.lherrera.jwtapp.dto;

/**
 * Esta clase fue diseñada para poder manejar los diferentes tipos de
 * respuestas, por ejemplo en el caso de token, es una cadena, para el caso del
 * usuario es un Usuario, por lo tanto, estos tipos de retornos se traducen a
 * distintos tipos en java, aunque sean todos json, poseen estructuras distintas
 * que deben ser manejadas con las técnicas que existen en java, antes de
 * finalmente ser transformadas en cadenas o json, son objetos, es por ello que
 * la respuesta es un tipo <T>, por que el campo data, es lo que se busca por
 * estandar como el campo que contiene la información, es por eso que la
 * respuesta debe ser multipo, por que puede contender cualquuier tipo de
 * respuesta. Recordar que no puede ser con polimorfismo puro, como lo sería con
 * un tipo padre como tipo de respuesta, ya que este, debería contener todos los
 * métodos de cualquier tipo de variable, lo que es impensable. La ventaja de
 * <T> es que si le pasamos el tipo que sea, asume todos sus métodos, a
 * diferencia del polimorfismo que solamente asume los métodos del padre y para
 * ejecutar alguno que no posea, se debe hacer un cast. Usando <T> no tenemos
 * este problema.
 * 
 * @author luisherrera
 *
 * @param <T>
 */
public class RespuestaDTO<T> {

	private Integer status;
	private T data;

	public RespuestaDTO() {
	}

	public RespuestaDTO(Integer status, T data) {
		super();
		this.status = status;
		this.data = data;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public T getData() {
		return data;
	}

	public void setData(T data) {
		this.data = data;
	}

}
