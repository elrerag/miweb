/**
 * Luego de crear al usuario, lo accedemos con sus credenciales
 * para obtener un token.
 * 
 * POST: http://localhost:8080/api/v1/iniciarsesion?correo=l.herrera.garnica@gmail.com&password=1234
 * 
 * Sin cuerpo
 * 
 * Respuesta esperada, el token, sin el Bearer.
 * 
 */
package cl.lherrera.jwtapp.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import cl.lherrera.jwtapp.dto.RespuestaDTO;
import cl.lherrera.jwtapp.service.ServicioUsuario;

@RestController
@RequestMapping(path = "/api/v1/iniciarsesion")
public class ControladorIngreso {
	private Logger logger = LoggerFactory.getLogger(ControladorIngreso.class);

	@Autowired
	private ServicioUsuario servicioUsuario;

	@PostMapping(path = { "", "/" })
	public RespuestaDTO<String> iniciarSesion(@RequestParam String correo, @RequestParam String password) {
		logger.debug("Ejecutado: /api/v1/iniciarsesion, parámetros : " + " " + correo + " " + password);
		RespuestaDTO<String> respuesta = new RespuestaDTO<>();
		String data = servicioUsuario.iniciarSesion(correo, password);
		respuesta.setStatus(200);
		respuesta.setData(data);

		return respuesta;
	}
}
