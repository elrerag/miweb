package cl.lherrera.jwtapp.dto;

import java.util.List;

import cl.lherrera.jwtapp.model.Rol;

/**
 * Clase de transporte de datos, que contiene la estructura del objeto json
 * esperado en el frontEnd. En este caso, para el front, este elemento según la
 * técnica de puntos función sería un (EIF: External Interface File)
 * 
 * @author luisherrera
 *
 */
public class UsuarioDTO {

	private String nombre;
	private String email;
	private String password;
	private List<Rol> roles;

	public UsuarioDTO() {
	}

	public UsuarioDTO(String nombre, String email, String password, List<Rol> roles) {
		super();
		this.nombre = nombre;
		this.email = email;
		this.password = password;
		this.roles = roles;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public List<Rol> getRoles() {
		return roles;
	}

	public void setRoles(List<Rol> roles) {
		this.roles = roles;
	}

	@Override
	public String toString() {
		return "UsuarioDTO [nombre=" + nombre + ", email=" + email + ", password=" + password + ", roles=" + roles
				+ "]";
	}

}
