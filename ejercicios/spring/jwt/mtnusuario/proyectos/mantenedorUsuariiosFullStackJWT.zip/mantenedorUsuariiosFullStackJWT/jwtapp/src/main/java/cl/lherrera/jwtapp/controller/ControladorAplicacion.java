package cl.lherrera.jwtapp.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Método para comprobar si la api está disponible Es utilizado por monitores,
 * que ejecutan una petición a este endpoint, para poder verificar que esté
 * disponible o no.
 * 
 * @author luisherrera
 *
 */
@RestController
@RequestMapping(value = "/api/v1/isAlive")
public class ControladorAplicacion {

	@GetMapping(path = { "", "/" })
	public String isAlive() {
		return "200";
	}
}
