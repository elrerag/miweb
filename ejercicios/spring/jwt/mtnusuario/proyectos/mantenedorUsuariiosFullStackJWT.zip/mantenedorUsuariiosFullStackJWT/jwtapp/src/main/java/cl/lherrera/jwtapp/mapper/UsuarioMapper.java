package cl.lherrera.jwtapp.mapper;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cl.lherrera.jwtapp.dto.UsuarioDTO;
import cl.lherrera.jwtapp.model.Usuario;

/**
 * contiene toda la lógica necesaria para que las entidades sean transformadas en
 * los objetos que son requeridos para el servicio.
 * 
 * @author luisherrera
 *
 */
public class UsuarioMapper {
	private static Logger logger = LoggerFactory.getLogger(UsuarioMapper.class);

	private UsuarioMapper() {
	}

	/**
	 * Transforma un Usuario a un UsuarioDTO
	 */
	public static UsuarioDTO usuarioADto(Usuario usuario) {
		logger.debug("Usuario: " + usuario.toString());
		UsuarioDTO dtoUsuario = new UsuarioDTO();
		dtoUsuario.setNombre(usuario.getNombre() + " " + usuario.getApellido());
		dtoUsuario.setEmail(usuario.getUsername());
		dtoUsuario.setRoles(usuario.getRoles());
		dtoUsuario.setPassword(null);

		logger.debug("Transformado a DTO : " + dtoUsuario.toString());
		return dtoUsuario;
	}

	/**
	 * método privado para separar el nombre y el apellido que viene en un solo
	 * campo desde el front se separa si viene con espacio no es muy elegante pero
	 * es una solución rápida.
	 */
	private static List<String> getNombres(UsuarioDTO dtoUsuario) {
		return Arrays.asList(dtoUsuario.getNombre().split(" "));
	}

	/**
	 * Transforma un UsuarioDTO a un Usuario
	 */
	public static Usuario dtoAUsuario(UsuarioDTO dtoUsuario) {
		logger.debug("UsuarioDTO: " + dtoUsuario.toString());
		List<String> nombres = getNombres(dtoUsuario);
		String apellido = "";

		String nombre = (nombres.size() > 0) ? nombres.get(0) : null;
		if (nombres.size() > 1)
			apellido = (nombres.size() > 0) ? nombres.get(1) : null;

		Usuario usuario = new Usuario();
		usuario.setNombre(nombre);
		usuario.setApellido(apellido);
		usuario.setUsername(dtoUsuario.getEmail());
		usuario.setPassword(dtoUsuario.getPassword());
		usuario.setRoles(dtoUsuario.getRoles());

		logger.debug("Transformado a Usuario: " + usuario.toString());
		return usuario;
	}
}
