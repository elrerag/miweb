package cl.lherrera.jwtapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtappApplicationTests {

	@Test
	void contextLoads() {
	}

}
