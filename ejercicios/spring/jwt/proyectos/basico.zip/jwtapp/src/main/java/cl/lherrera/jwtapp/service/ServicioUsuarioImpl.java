package cl.lherrera.jwtapp.service;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import cl.lherrera.jwtapp.apiexception.RestServiceException;
import cl.lherrera.jwtapp.dao.UsuarioDao;
import cl.lherrera.jwtapp.dto.UsuarioDTO;
import cl.lherrera.jwtapp.mapper.UsuarioMapper;
import cl.lherrera.jwtapp.model.Usuario;
import cl.lherrera.jwtapp.security.JwtTokenProvider;

@Service
public class ServicioUsuarioImpl implements ServicioUsuario {
	private Logger logger = LoggerFactory.getLogger(ServicioUsuarioImpl.class);

	@Autowired
	UsuarioDao daoUsuario;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenProvider jwtTokenProvider;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Override
	public String iniciarSesion(String correo, String contrasenia) {
		String token = "";
		logger.debug("Inicio de la sesión: correo: " + correo + "contraseña: " + contrasenia);
		try {
			// intenta crear la autenticación.
			// si no puede, se envía un AuthenticationException.
			Authentication objetoAutentificacion = new UsernamePasswordAuthenticationToken(correo, contrasenia);
			authenticationManager.authenticate(objetoAutentificacion);
			Usuario usuarioAutenticado = daoUsuario.findByUsername(correo).orElse(null);
			if (usuarioAutenticado != null)
				token = generaToken(usuarioAutenticado);

		} catch (AuthenticationException e) {
			throw new RestServiceException("username o password invalido", HttpStatus.UNPROCESSABLE_ENTITY);
		}

		return token;
	}

	private String generaToken(Usuario usuario) {
		String token = jwtTokenProvider.createToken(usuario.getUsername(), usuario.getRoles());
		logger.debug("Token generado: ..." + token.substring(token.length() - 5));

		return token;
	}

	@Override
	public List<UsuarioDTO> listaDeUsuarios() {

		List<UsuarioDTO> usuarios = daoUsuario.findAll().stream()
				// cada uno de los usuarios pasando a un DTO
				.map(usuario -> UsuarioMapper.usuarioADto(usuario)).collect(Collectors.toList());

		logger.debug("Lista de usuarioDTO: " + usuarios.toString());
		return usuarios;
	}

	@Override
	public String registraNuevoUsuario(UsuarioDTO dtoUsuario) {
		String token = null;
		// verificar si el usuario existe para no ingresarlo otra vez
		Usuario usuario = daoUsuario.findByUsername(dtoUsuario.getEmail()).orElse(null);
		
		if (usuario == null) {
			String constraseniaEnDuro = dtoUsuario.getPassword();
			String constraseniaEncriptada = passwordEncoder.encode(constraseniaEnDuro);
			dtoUsuario.setPassword(constraseniaEncriptada);
			// guardamos el usuario convertido desde un DTO
			usuario = UsuarioMapper.dtoAUsuario(dtoUsuario);

			logger.debug("Registrando nuevo usuario: " + usuario.toString());
			daoUsuario.save(usuario);

			logger.debug("Usuario nuevo registrado: " + usuario.toString());
			logger.debug("Generando token... ");

			token = this.generaToken(usuario);
		}

		return token;
	}

	/**
	 * Se implementa desde UserDetailsService, interface que extiende 
	 * ServicioUsuario.
	 * 
	 * Se supone que se debe cargar el nombre de usuario y en este caso es 
	 * correo, es por que se exige un valor de nombre de usuario, que puede ser
	 * por ejemplo: rut, correo, nombre de usuario, tag name, etc. El cómo se maneje
	 * dependerá de nuestra implementación.
	 * 
	 * Construye un `UserDetails` estático, con la información que se le
	 * proporcione. En este caso, el nombre de usuario que venía como argumento y la
	 * contraseña que está en la base de datos. Este proceso es implementado ya que
	 * este único método, posee acceso a la contraseña del usuario. La técnica usada
	 * es que cada método retorna un `UserBuilder`, hasta llegar a `build()`, es
	 * cuando finalmente es convertido en un `UserDetail`.
	 * 
	 **/
	@Override
	public UserDetails loadUserByUsername(String correo) throws UsernameNotFoundException {
		final Usuario user = daoUsuario.findByUsername(correo).orElse(null);
		if (user == null) {
			throw new UsernameNotFoundException("Usuario '" + correo + "' no encontrado");
		}
		return org.springframework.security.core.userdetails.User//
				.withUsername(correo).password(user.getPassword()).authorities(user.getRoles()).accountExpired(false)
				.accountLocked(false).credentialsExpired(false).disabled(false).build();
	}

}
