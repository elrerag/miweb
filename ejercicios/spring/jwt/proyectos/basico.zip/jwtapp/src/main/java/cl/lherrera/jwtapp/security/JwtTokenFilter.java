package cl.lherrera.jwtapp.security;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import cl.lherrera.jwtapp.apiexception.RestServiceException;


public class JwtTokenFilter extends OncePerRequestFilter {
	private JwtTokenProvider jwtTokenProvider;

	public JwtTokenFilter(JwtTokenProvider jwtTokenProvider) {
		this.jwtTokenProvider = jwtTokenProvider;
	}

	@Override
	protected void doFilterInternal(
			HttpServletRequest request, 
			HttpServletResponse respose, 
			FilterChain filterChain)
			throws ServletException, IOException {

		// extraemos el token del request, este debe ir en el header
		// con el nombre Authentication y en el valor
		String token = jwtTokenProvider.resolveToken(request);

		try {
			// si el token no es nulo y si es válido...
			if (token != null && jwtTokenProvider.validateToken(token)) {
				// creamos un objeto (new UsernamePasswordAuthenticationToken)
				// ya las credenciales no están disponibles, solamente `userDetails``
				Authentication auth = jwtTokenProvider.getAuthentication(token);
				SecurityContextHolder.getContext().setAuthentication(auth);
			}
		} catch (RestServiceException ex) {

			SecurityContextHolder.clearContext();
			respose.sendError(ex.getHttpStatus().value(), ex.getMessage());
			return;

		}
		filterChain.doFilter(request, respose);
	}
}
