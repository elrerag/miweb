package cl.lherrera.jwtapp.model;

import org.springframework.security.core.GrantedAuthority;

public enum Rol implements GrantedAuthority {
	ROLE_ADMINISTRADOR, ROLE_USUARIO;

	@Override
	public String getAuthority() {
		return name();
	}

}
