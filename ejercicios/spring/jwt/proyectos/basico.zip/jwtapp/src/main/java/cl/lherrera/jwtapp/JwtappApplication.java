package cl.lherrera.jwtapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtappApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtappApplication.class, args);
	}

}
