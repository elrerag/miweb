package cl.lherrera.jwtapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.lherrera.jwtapp.dto.UsuarioDTO;
import cl.lherrera.jwtapp.service.ServicioUsuario;


@RestController
@RequestMapping("/api/v1/usuarios")
public class ControladorUsuario {

	@Autowired
	private ServicioUsuario servicioUsuario;

	/**
	 * Servicio para listar los usuarios, requiere ser accedido mediante el uso de
	 * tokens <code>
	 * POST: http://localhost:8080/api/v1/usuarios/
	 * 
	 * Headers
	 * 
	 * {
	 *     Autorizacion: Bearer ...token que generemos, este parámetro 
	 *     lo personalizamos en HEADER_AUTHORIZATION_KEY (JwtToken.java)
	 * }
	 * </code>
	 */
	@GetMapping(path = { "", "/" })
	public List<UsuarioDTO> listar() {

		return servicioUsuario.listaDeUsuarios();
	}

}
