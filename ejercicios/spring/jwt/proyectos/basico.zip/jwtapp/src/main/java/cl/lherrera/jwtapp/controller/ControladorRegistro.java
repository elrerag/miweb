/**
 * Servicio que registra a un usuario. Se pide que además retorne el token.
 * No es bueno que un método realice dos tareas principales. Pero en esta ocación
 * lo hacemos para obtener el token y no tener que hacer el login. En un sistema
 * productivo, debería solo registrar. Luego, deberíamos iniciar sesión de manera manual
 * 
 * Headers:
 * 	Content-Type:application/json
 * POST:
 * 	http://localhost:8080/api/v1/registrar
 * BODY-EXAMPLE
 * 
 * <code>
{
	"nombre": "Luis Herrera",
	"email": "l.herrera.garnica@gmail.com",
	"password": "1234",
	"roles": ["ROLE_ADMINISTRADOR"]
}
<code>
 */
package cl.lherrera.jwtapp.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cl.lherrera.jwtapp.dto.UsuarioDTO;
import cl.lherrera.jwtapp.service.ServicioUsuario;

// para que no retorne vistas.
@RestController
@RequestMapping(path = "/api/v1/registrar")
public class ControladorRegistro {
	private Logger logger = LoggerFactory.getLogger(ControladorRegistro.class);

	@Autowired
	ServicioUsuario servicioUsuario;

	@PostMapping(path = { "", "/" })
	public String registrarUsuaio(@RequestBody UsuarioDTO usuarioDTO) {
		logger.debug("Registrando al usuario: " + usuarioDTO.toString());
		return servicioUsuario.registraNuevoUsuario(usuarioDTO);
	}

}
