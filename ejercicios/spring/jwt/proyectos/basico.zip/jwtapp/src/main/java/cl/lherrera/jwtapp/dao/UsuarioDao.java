package cl.lherrera.jwtapp.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cl.lherrera.jwtapp.model.Usuario;

@Repository
public interface UsuarioDao extends JpaRepository<Usuario, Integer> {
	boolean existsByUsername(String username);
	Optional<Usuario> findByUsername(String username);
}
