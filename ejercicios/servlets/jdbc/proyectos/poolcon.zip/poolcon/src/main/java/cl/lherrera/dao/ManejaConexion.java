package cl.lherrera.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Logger;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;



public class ManejaConexion {

	private static final Logger milog = Logger.getLogger(ManejaConexion.class.getName());
	
	private static ManejaConexion manejaConexion = new ManejaConexion();

	private ManejaConexion() {
		if (manejaConexion != null){
			//Prevent Reflection
			throw new IllegalStateException("No se puede crear una nueva instancia de ManejaConexion");
		}
	}
	
	public static ManejaConexion obtenerManejo() {
		return manejaConexion;
	}

	public Connection obtenerConexion() throws SQLException {
		Connection conexion = null;

		try {
			InitialContext contextoInicial = new InitialContext(); 
			DataSource ds = (DataSource) contextoInicial.lookup("java:comp/env/jdbc/mydb");
			conexion = ds.getConnection(); 
			
		} catch (NamingException e) {
			milog.severe("No se pudo obtener conexión del pool");
			milog.severe(e.getMessage());
		}
		return conexion;
	}
	

}
