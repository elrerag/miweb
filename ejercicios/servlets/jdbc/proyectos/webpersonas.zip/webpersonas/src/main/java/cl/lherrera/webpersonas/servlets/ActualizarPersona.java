package cl.lherrera.webpersonas.servlets;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cl.lherrera.webpersonas.dao.PersonaDAO;
import cl.lherrera.webpersonas.modelo.Persona;
import cl.lherrera.webpersonas.utils.MiLog;


@WebServlet(name = "Actualizar Persona", urlPatterns = "/actualizar")
public class ActualizarPersona extends HttpServlet{

	private static final Logger logger = MiLog.obtenerLog();
	private static final long serialVersionUID = 6755151974107090793L;
	private static PersonaDAO daoPersona = new PersonaDAO();

	private void procesaGetRequest(HttpServletRequest req) {
		List<Persona> personas = daoPersona.obtenerTodos();
		req.setAttribute("personas", personas);
		
		// bloqueo de formularios
		req.setAttribute("insertForm", "disabled");
		req.setAttribute("updateForm", "");
		req.setAttribute("deleteForm", "disabled");
		
		// parámetros para el formulario
		req.setAttribute("id", req.getParameter("id") );
		req.setAttribute("nombre", req.getParameter("nombre") );
	}
	
	private void procesaPostRequest(HttpServletRequest req) {
		if(req.getParameter("id") != null) {
			int idPersona = Integer.parseInt(req.getParameter("id"));
			String nombrePersona = req.getParameter("nombre");
			Persona persona = new Persona(nombrePersona);
			daoPersona.actualizar(idPersona, persona);
		}else {
			logger.warning("El request no posee los datos necesarios");
		}
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		procesaGetRequest(req);
		try {
			req.getRequestDispatcher("mantenedor.jsp").forward(req, resp);
		} catch (ServletException | IOException e) {
			logger.severe(e.getMessage());
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
		procesaPostRequest(req);
		try {
			// no llamamos directo al jsp. si no que al servlet que carga
			// la ventana inicial
			req.getRequestDispatcher("mantenedor").forward(req, resp);
		} catch (ServletException | IOException e) {
			logger.severe(e.getMessage());
		}
		
	}

}
