package cl.lherrera.webpersonas.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Logger;


public class ManejaConexion {
	// cargamos las propiedades del proyecto
	private static Propiedades propiedades = Propiedades.obtenerPropiedades();
	private static Properties props = propiedades.getProps();
	
	private static final String DB_URL = "jdbc:sqlite:" + props.getProperty("file_path");
	private static final Logger milog = MiLog.obtenerLog();
	
	private static ManejaConexion manejaConexion = new ManejaConexion();

	private ManejaConexion() {
		if (manejaConexion != null){
			//Prevent Reflection
			throw new IllegalStateException("No se puede crear una nueva instancia de ManejaConexion");
		}
	}
	
	/**
	 * Método estático, para poder acceder sin una instancia, así controlamos
	 * internamente que no se cree una nueva instancia si esta existe.
	 * 
	 */
	public static ManejaConexion obtenerManejo() {
		return manejaConexion;
	}

	/**
	 * Obtiene una conexión.
	 * 
	 * @return Una conexión abierta, esto es importante ya que esta conexión debe ser cerrada.
	 * @throws <i>SQLException</i>, al no controlar la exception acá, obligamos
	 * a tener que utilizar un {@code try()}, así cada vez que lo ocupemos
	 * estará dentro del try especial y nos aseguramos que la conexión
	 * cierre. Pero esta característica, se encuentra vulnerable al
	 * desarrollador si ocupa o no {@code try(){}catch(){}}. 
	 */
	public Connection obtenerConexion() throws SQLException {
		Connection conexion = null;
		
		try {
			Class.forName("org.sqlite.JDBC");
			conexion = DriverManager.getConnection(
				DB_URL, 
				props.getProperty("usuario"), 
				props.getProperty("contrasenia")
			);
			
		} catch (ClassNotFoundException e) {
			milog.severe("No se pudo cargar el driver.");
			milog.severe(e.getMessage());
		}
		
		return conexion;
	}

}
