package cl.lherrera.webpersonas.servlets;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cl.lherrera.webpersonas.dao.PersonaDAO;
import cl.lherrera.webpersonas.modelo.Persona;
import cl.lherrera.webpersonas.utils.MiLog;


@WebServlet(name = "Eliminar Persona", urlPatterns = "/eliminar")
public class EliminaPersona extends HttpServlet{
	private static final Logger logger = MiLog.obtenerLog();
	private static final long serialVersionUID = 6755151974107090793L;
	private static PersonaDAO daoPersona = new PersonaDAO();
	
	private void procesaGetRequest(HttpServletRequest req) {
		List<Persona> personas = daoPersona.obtenerTodos();
		req.setAttribute("personas", personas);
		
		// bloqueo de formularios
		req.setAttribute("insertForm", "disabled");
		req.setAttribute("updateForm", "disabled");
		req.setAttribute("deleteForm", "");
		
		// datos de los valores del formulario
		if(req.getParameter("id") != null && req.getParameter("elNombre") != null) {
			req.setAttribute("id", req.getParameter("id") );
			req.setAttribute("elNombre", req.getParameter("elNombre") );	
		}else {
			logger.warning("El request no posee los datos necesarios");
		}
	}
	
	private void procesaPostRequest(HttpServletRequest req) {
		if(req.getParameter("id") != null) {
			int personaId = Integer.parseInt(req.getParameter("id") );
			daoPersona.eliminar(personaId );	
		}else {
			logger.warning("El request no posee los datos necesarios");
		}
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		procesaGetRequest(req);
		try {
			req.getRequestDispatcher("mantenedor.jsp").forward(req, resp);
		} catch (ServletException | IOException e) {
			logger.severe(e.getMessage());
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
		procesaPostRequest(req);

		try {
			req.getRequestDispatcher("mantenedor").forward(req, resp);
		} catch (ServletException | IOException e) {
			logger.severe(e.getMessage());
		}
		
	}
}
