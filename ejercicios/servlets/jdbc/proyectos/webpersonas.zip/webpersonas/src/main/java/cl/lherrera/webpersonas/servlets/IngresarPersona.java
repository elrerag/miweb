package cl.lherrera.webpersonas.servlets;

import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cl.lherrera.webpersonas.dao.PersonaDAO;
import cl.lherrera.webpersonas.modelo.Persona;
import cl.lherrera.webpersonas.utils.MiLog;


@WebServlet(name = "IIngresar Persona", urlPatterns = "/ingresar")
public class IngresarPersona extends HttpServlet{

	private static final Logger logger = MiLog.obtenerLog();
	private static final long serialVersionUID = 6755151974107090793L;
	private static PersonaDAO daoPersona = new PersonaDAO();
	
	private void procesaGetRequest(HttpServletRequest req) {
		if(req.getParameter("nombre") != null) {
			String nombre = req.getParameter("nombre");
			daoPersona.ingresar(new Persona(nombre) );
		}else {
			logger.warning("El request no posee los datos necesarios");
		}

	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
		procesaGetRequest(req);
		try {
			// el servlet que escucha esta url, se encarga de dejar el jsp
			// en un estado consistente inicial.
			req.getRequestDispatcher("mantenedor").forward(req, resp);
		} catch (ServletException | IOException e) {
			logger.severe(e.getMessage());
		}
		
	}
}
