package cl.lherrera.webpersonas.utils;


import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Logger;

public class Propiedades {
	private Properties props;
	private static Logger milog = MiLog.obtenerLog();
	private static Propiedades propiedades = new Propiedades();
	InputStream streamDeBytes = this.getClass().getResourceAsStream("/config/propiedades.properties");
	
	private Propiedades() {
		if (propiedades != null){
			//Prevent Reflection
			throw new IllegalStateException("No se puede crear una nueva instancia de Propiedades");
		}
		this.iniciaProps();
	}

	public static Propiedades obtenerPropiedades() {
		return propiedades;
	}

	private void iniciaProps() {
		try {
			props = new Properties();
			props.load(streamDeBytes);
		} catch (FileNotFoundException e) {
			milog.severe("El archivo:, no se ha encontrado");
			milog.severe(e.getMessage());
		} catch (IOException e) {
			milog.severe(e.getMessage());
		}
	}
	
	public Properties getProps() {
		return props;
	}

}
