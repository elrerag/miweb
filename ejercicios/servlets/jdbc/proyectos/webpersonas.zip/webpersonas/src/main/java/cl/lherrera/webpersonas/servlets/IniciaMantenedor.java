package cl.lherrera.webpersonas.servlets;

import java.io.IOException;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cl.lherrera.webpersonas.dao.PersonaDAO;
import cl.lherrera.webpersonas.modelo.Persona;
import cl.lherrera.webpersonas.utils.MiLog;


@WebServlet(name = "Mantenedor de Personas", urlPatterns = "/mantenedor")
public class IniciaMantenedor extends HttpServlet{
	private static final Logger logger = MiLog.obtenerLog();
	private static PersonaDAO daoPersona = new PersonaDAO();

	private static final long serialVersionUID = -4282664097471786333L;
	
	/**
	 * Procesa el request por referencia, modifica el mismo objeto req
	 * este objeto, irá al jsp para allí finalizar la entrega del
	 * response.
	 */
	private void procesaGetRequest(HttpServletRequest req) {

		// se llena la lista para la tabla
		List<Persona> personas = daoPersona.obtenerTodos();
		req.setAttribute("personas", personas);

		// usado para bloquear elementos del formulario
		req.setAttribute("insertForm", "");
		req.setAttribute("updateForm", "disabled");
		req.setAttribute("deleteForm", "disabled");
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		procesaGetRequest(req);
		try {
			req.getRequestDispatcher("mantenedor.jsp").forward(req, resp);
		} catch (ServletException | IOException e) {
			logger.severe(e.getMessage());
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp){
		// cuando un doPost solicita la carga mediante un forward...
		doGet(req, resp);
	}

}