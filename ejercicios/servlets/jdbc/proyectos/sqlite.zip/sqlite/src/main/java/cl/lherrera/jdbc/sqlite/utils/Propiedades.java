package cl.lherrera.jdbc.sqlite.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Logger;

public class Propiedades {
	private Properties props;
	private static Logger milog = MiLog.obtenerLog();
	private static Propiedades propiedades = new Propiedades();
	
	private Propiedades() {
		if (propiedades != null){
			//Prevent Reflection
			throw new IllegalStateException("No se puede crear una nueva instancia de Propiedades");
		}
		this.iniciaProps();
	}

	public static Propiedades obtenerPropiedades() {
		return propiedades;
	}

	private void iniciaProps() {
		try {
			props = new Properties();
			props.load(new FileInputStream("propiedades"));
		} catch (FileNotFoundException e) {
			milog.severe("El archivo no se ha encontrado");
			milog.severe(e.getMessage());
		} catch (IOException e) {
			milog.severe(e.getMessage());
		}
	}
	
	public Properties getProps() {
		return props;
	}

}
