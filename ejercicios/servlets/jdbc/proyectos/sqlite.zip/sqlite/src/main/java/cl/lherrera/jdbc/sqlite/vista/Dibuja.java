package cl.lherrera.jdbc.sqlite.vista;

import java.util.List;

import cl.lherrera.jdbc.sqlite.modelo.Persona;

public class Dibuja {
	
	public static void solicitaNombre() {
		System.out.println("Ingrese el nombre de la persona");
	}
	
	public static void solicitaId() {
		System.out.println("Ingrese el id de la persona");
	}
	
	public static void principal() {
		limpiarPantalla();
		String texto = ""
			+ "Menú principal \n\n"
			+ "1 - Listar personas\n"
			+ "2 - Ingresar persona\n"
			+ "3 - Actuaizar persona\n"
			+ "4 - Eliminar persona\n"
			+ "5 - Salir\n";
			
		System.out.println(texto);
		
	}

	public static void muestraDetallePersona(Persona persona) {
		System.out.println("Persona a ejecutar acción:");
		System.out.println("--------------------------");
		System.out.println("- id: " + persona.getId());
		System.out.println("- nombre: " + persona.getNombre());
		System.out.println("--------------------------");
		System.out.println("Desea ejecutar: 1-Si, 2-No");
	}
	
	public static void listarTodos(List<Persona> personas) {
		System.out.println("Lista de personas:");
		personas.forEach(System.out::println);
	}
	
	public static void confirmaSegir() {
		System.out.println("\n\nAcción realizada para continuar presione 'ENTER'...");
	}
	
	private static void limpiarPantalla() {
		for(int i = 0; i < 10; i ++) {
			System.out.println("\n");
		}
	}
	
}
