package cl.lherrera.jdbc.sqlite.vista;

import java.util.Scanner;

/**
 * Clase encargada de gestionar las acciones del usuario.
 * Todos sus métodos son estáticos.
 * @author luisherrera
 *
 */
public class Accion {
	private static final Scanner SCAN = new Scanner(System.in);
	
	private Accion() {}
	
	public static int retornaOpcionEntera() {
		return Integer.parseInt(SCAN.nextLine());
	}
	
	public static void avisoAccionRealizada() {
		Dibuja.confirmaSegir();
		SCAN.nextLine();
		
	}

	public static String retornaOpcion() {
		return SCAN.nextLine();
	}
	
	public static int solicitaId() {
		Dibuja.solicitaId();
		return retornaOpcionEntera();
	}

	public static String solicitaNombre() {
		Dibuja.solicitaNombre();
		return retornaOpcion();
	}
	
	public static void finalizaAccion() {
		SCAN.close();
	}
}
