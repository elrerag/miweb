package cl.lherrera.jdbc.sqlite.utils;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;


public class MiLog {
	private Propiedades propiedades = Propiedades.obtenerPropiedades();
	private Properties props = propiedades.getProps();
	private static Logger logger = Logger.getLogger(MiLog.class.getName());

	// cramos la instancia desde el inicio, ya que llamando a un método
	// se corre el riesgo que más de un hilo crea que milog
	// es null hasta que se ejecute el método que crea
	// la instancia.
	private static MiLog milog = new MiLog();

	private MiLog() {
		
		if (milog != null){
			//Prevent Reflection
			throw new IllegalStateException("No se puede crear una nueva instancia de Milog");
		}
		this.inicializaArchivo();
	}

	private void inicializaArchivo() {
		SimpleDateFormat formatoSimple = new SimpleDateFormat("yyyy_MM_dd");
		String fecha = formatoSimple.format(new Date());
	    try {
	    	String directorioLogs = props.getProperty("directorioLogs");
	    	boolean existeElDirectorio = verificaExistenciaDirecctorio(directorioLogs);

	    	if(existeElDirectorio) {
	    		String direccionArchivo = directorioLogs + fecha + ".log";
	    		FileHandler fh = new FileHandler(direccionArchivo);
		        logger.addHandler(fh);
		        SimpleFormatter formatter = new SimpleFormatter();  
		        fh.setFormatter(formatter);
	    	} else {
	    		throw new IOException("No se pudo crear el directorio: " + directorioLogs);
	    	}
	    } catch (SecurityException | IOException e) {
	        logger.severe(e.getMessage());
	    }
	}

	/**
	 * Toma la ruta y la intenta crear en caso que no exista 
	 */
	private boolean verificaExistenciaDirecctorio(String directorioLogs) {
		boolean existe = false;
		File manejoDirectorio = new File(directorioLogs);
		
		if(manejoDirectorio.exists()) {
			existe = true;
		}else {
			existe = manejoDirectorio.mkdir();
		}
    	return existe;
	}

	public static  Logger obtenerLog() {				

		return logger;
	}

}
