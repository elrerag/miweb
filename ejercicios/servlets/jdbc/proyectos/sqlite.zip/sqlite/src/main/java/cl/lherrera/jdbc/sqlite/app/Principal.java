package cl.lherrera.jdbc.sqlite.app;

import cl.lherrera.jdbc.sqlite.utils.AdministradorDeAplicacion;

public class Principal {
	
	public static void main(String[] args) {
		AdministradorDeAplicacion aplicacion = AdministradorDeAplicacion.obtenerEjecucion();
		aplicacion.iniciaApp();
	}
}