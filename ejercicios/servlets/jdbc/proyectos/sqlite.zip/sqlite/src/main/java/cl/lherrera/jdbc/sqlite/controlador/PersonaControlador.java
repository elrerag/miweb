package cl.lherrera.jdbc.sqlite.controlador;

import java.util.List;

import cl.lherrera.jdbc.sqlite.dao.PersonaDAO;
import cl.lherrera.jdbc.sqlite.modelo.Persona;
import cl.lherrera.jdbc.sqlite.utils.AdministradorDeAplicacion;
import cl.lherrera.jdbc.sqlite.vista.Accion;
import cl.lherrera.jdbc.sqlite.vista.Dibuja;

public class PersonaControlador {
	private final PersonaDAO daopersona = new PersonaDAO();
	private static final int LISTAR = 1;
	private static final int INGRESAR = 2;
	private static final int ACTUALIZAR = 3;
	private static final int ELIMINAR = 4;
	
	public void procesoIngresar() {
		Persona persona = new Persona(Accion.solicitaNombre());
		daopersona.ingresar(persona);
		Accion.avisoAccionRealizada();
	}
	
	public void procesoListar() {
		List<Persona> personas = daopersona.obtenerTodos();
		Dibuja.listarTodos(personas);
		Accion.avisoAccionRealizada();
	}
	
	public void procesoActualizar() {
		int id = Accion.solicitaId();
		Persona persona = daopersona.buscarPorId(id);
		Dibuja.muestraDetallePersona(persona);
		int opcion = Accion.retornaOpcionEntera();
		if(opcion == 1) {
			String nombre = Accion.solicitaNombre();
			persona.setNombre(nombre);
			daopersona.actualizar(id, persona);
		}
		Accion.avisoAccionRealizada();
	}
	
	public void procesoEliminar() {
		int id = Accion.solicitaId();
		Persona persona = daopersona.buscarPorId(id);
		Dibuja.muestraDetallePersona(persona);
		int opcion = Accion.retornaOpcionEntera();
		if(opcion == 1)
			daopersona.eliminar(id);
		
		Accion.avisoAccionRealizada();
	}
	
	public void iniciaMantenedor() {
		Dibuja.principal();
		int opcion = Accion.retornaOpcionEntera();
		switch (opcion) {
		case LISTAR:
			procesoListar();
			break;
		case INGRESAR:
			procesoIngresar();
			break;
		case ACTUALIZAR:
			procesoActualizar();
			break;
		case ELIMINAR:
			procesoEliminar();
			break;
		default:
			Accion.finalizaAccion();
			AdministradorDeAplicacion aplicacion = AdministradorDeAplicacion.obtenerEjecucion();
			aplicacion.terminarAplicacion();
		}
	}

}
