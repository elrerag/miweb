package cl.lherrera.jdbc.sqlite.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import cl.lherrera.jdbc.sqlite.modelo.Persona;
import cl.lherrera.jdbc.sqlite.utils.ManejaConexion;
import cl.lherrera.jdbc.sqlite.utils.MiLog;

public class PersonaDAO {
	private static final ManejaConexion manejaConexion = ManejaConexion.obtenerManejo();
	private static Logger milog = MiLog.obtenerLog();
	
	/**
	 * Método encargado de agregar una persona a la
	 * base de datos.
	 */
	public int ingresar(Persona persona) {
		int filasAfectadas = 0;
		
		try(
			Connection conexion = manejaConexion.obtenerConexion();
			PreparedStatement ps = conexion.prepareStatement("INSERT INTO persona (nombre) values (?)");
		){
			ps.setString(1, persona.getNombre());
			filasAfectadas = ps.executeUpdate();
			
			if(filasAfectadas != 1)
				throw new SQLException("Error al insertar registro");
			
		}catch (SQLException e) {
			milog.severe(e.getMessage());
		}
		
		return filasAfectadas;
	}
	
	/**
	 * Método encargado de retornar una lista de todas las personas
	 * que estén en la base de datos.
	 * 
	 * @return {@code List} lista poblada con las personas encontradas
	 * en la base de datos.
	 */
	public List<Persona> obtenerTodos(){
		List<Persona> personas = new ArrayList<>();
		
		try(
			Connection conexion = manejaConexion.obtenerConexion();
			PreparedStatement ps = conexion.prepareStatement("SELECT id, nombre FROM persona");
			ResultSet rs = ps.executeQuery();
		){
				
			while(rs.next()) {
				personas.add(new Persona(rs.getInt("id"), rs.getString("nombre")));
			}
		}catch (SQLException e) {
			milog.severe(e.getMessage());
		}
		
		return personas;
	}

	
	public Persona buscarPorId(int id) {
		Persona persona = new Persona();
		
		try(
			Connection conexion = manejaConexion.obtenerConexion();
			PreparedStatement ps = conexion.prepareStatement("SELECT id, nombre FROM persona where id = " + id );
			ResultSet rs = ps.executeQuery();
		){
			if(rs.next()) {
				persona.setNombre(rs.getString("nombre"));
				persona.setId(rs.getInt("id"));	
			}else {
				throw new SQLException("No se encuentra el registro en la base de datos");				
			}

		}catch (SQLException e) {
			milog.severe(e.getMessage());
		}
		
		return persona;
	}
	
	public void actualizar(int id, Persona persona) {
		try(
			Connection conexion = manejaConexion.obtenerConexion();
			PreparedStatement ps = conexion.prepareStatement("UPDATE persona SET nombre = ? WHERE id = ?");
		){
			ps.setString(1, persona.getNombre());
			ps.setInt(2, id);
			int filasAfectadas = ps.executeUpdate();
			if(filasAfectadas <= 0)
				throw new SQLException("No se actualizó ningún registro"); 
		}catch(SQLException e) {
			milog.severe("Error al actualizar");
			milog.severe(e.getMessage());
		}
		
	}
	
	public void eliminar(int id) {
		try(
				Connection conexion = manejaConexion.obtenerConexion();
				PreparedStatement ps = conexion.prepareStatement("DELETE FROM persona WHERE id = ?");
			){
				ps.setInt(1, id);
				int filasAfectadas = ps.executeUpdate();
				if(filasAfectadas <= 0)
					throw new SQLException("No se eliminó ningún registro"); 
			}catch(SQLException e) {
				milog.severe("Error al eliminar");
				milog.severe(e.getMessage());
			}
	}
	

}
