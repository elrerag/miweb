package cl.lherrera.jdbc.sqlite.utils;

import java.util.logging.Logger;

import cl.lherrera.jdbc.sqlite.controlador.PersonaControlador;


public class AdministradorDeAplicacion {
	private static Logger milog = MiLog.obtenerLog();
	
	private PersonaControlador controladorPersona = new PersonaControlador();
	private boolean seguirEjecutando = true;

	private static AdministradorDeAplicacion aplicacion = new AdministradorDeAplicacion();
	private AdministradorDeAplicacion() {
		if (aplicacion != null){
			//Prevent Reflection
			throw new IllegalStateException("No se puede crear una nueva instancia de AplicacionControlador");
		}
	}
	
	/**
	 * Acceso a la instancia desde el exterior
	 * 
	 */
	public static AdministradorDeAplicacion obtenerEjecucion() {		
		return aplicacion; 
	}
	
	/**
	 * se encarga de finalizar la aplicación, para esto cambia
	 * el valor de la variable estática que posee el while
	 * principal.
	 * 
	 */
	public void terminarAplicacion() {
		seguirEjecutando = false;
	}
	

	/**
	 * Método principal, es el que mantiene la aplicación ejecutando el menú.
	 */
	public void iniciaApp() {
		milog.info("Aplicación iniciada.");
		while(seguirEjecutando) {
			controladorPersona.iniciaMantenedor();
		}
		milog.info("Aplicación finalizada.");
	}

}
