package cl.lherrera.auth002.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ManejaSensible extends HttpServlet{

	private static final long serialVersionUID = -8273382432698807110L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp){
		try {
			req.getRequestDispatcher("/protegido/paginasegura.jsp").forward(req, resp);
		} catch (ServletException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	

}
