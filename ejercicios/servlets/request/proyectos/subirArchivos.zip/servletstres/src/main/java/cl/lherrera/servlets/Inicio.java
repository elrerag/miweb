package cl.lherrera.servlets;

import java.io.File;
import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;


public class Inicio extends HttpServlet{

	private static final long serialVersionUID = -4126615102927566280L;
	private static Logger milog = Logger.getLogger(Inicio.class.getName());
	private static final String SAVE_DIR = "/Users/luisherrera/Desktop/TALENTO-PROS/servlets/servletstres/WebContent/archivos";

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		try {
			req.getRequestDispatcher("inicio.jsp").forward(req, resp);
		} catch (ServletException | IOException e) {
			milog.severe(e.getMessage());
		}
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
		
		// verificar direcctorio ()
		File direcctorio = new File(SAVE_DIR);
		if (!direcctorio.exists())
			direcctorio.mkdir();
		try {
			// capturamos el nombre
			String nombre = req.getParameter("nombre");
			Part filePart = req.getPart("file");
			String fileName = nombre + "-" + filePart.getSubmittedFileName();
			filePart.write(SAVE_DIR + File.separator + fileName); 

			resp.getWriter().println("Archivo almacenado");
		} catch (IOException | ServletException e) {
			milog.info(e.getMessage());
		}
	}
}
