package cl.lherrera.sesion.servlets;

import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Comprueba extends HttpServlet{

	private static final long serialVersionUID = 142114490806232148L;
	private static Logger logger = Logger.getLogger(Comprueba.class.getName());
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		// sin hacer nada más que redirigir
		try {
			req.getRequestDispatcher("comprueba.jsp").forward(req, resp);
		} catch (ServletException | IOException e) {
			logger.severe(e.getMessage());
		}
	}
}
