package cl.lherrera.sesion.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cl.lherrera.session.modelo.Usuario;

public class ProcesaForm extends HttpServlet{

	private static final long serialVersionUID = 1421144908062873148L;
	Logger logger = Logger.getLogger(ProcesaForm.class.getName());
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) {
		HttpSession session = req.getSession();
		List<Usuario> usuarios = new ArrayList<>();
		
		if(req.getParameter("usuarios") == null) {
			session.setAttribute("usuarios", usuarios);
		}
		
		usuarios = (List<Usuario>) session.getAttribute("usuarios");

		String nombre = req.getParameter("nombre");
		String correo = req.getParameter("correo");
		String telefono = req.getParameter("telefono");
		
		Usuario usuario = new Usuario();
		usuario.setNombre(nombre);
		usuario.setCorreo(correo);
		usuario.setTelefono(telefono);
		
		usuarios.add(usuario);
		
		session.removeAttribute("usuarios");
		session.setAttribute("usuarios", usuarios);
		
		try {
			req.getRequestDispatcher("recibe.jsp").forward(req, resp);
		} catch (ServletException | IOException e) {
			logger.severe(e.getMessage());
		}
		
	}

}
