package cl.lherrera.sesion.servlets;

import java.io.IOException;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class CerrarSesion extends HttpServlet{

	private static final long serialVersionUID = -7437014430757537933L;
	private static Logger logger = Logger.getLogger(CerrarSesion.class.getName());
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		HttpSession session = req.getSession();
		
		session.removeAttribute("usuarios");
		session.invalidate();
		req.setAttribute("mensaje", "Sesión eliminada...");
        try {
            req.getRequestDispatcher("index.jsp").forward(req, resp);
        } catch (ServletException | IOException e) {
            logger.severe(e.getMessage());
        }
	}

}
