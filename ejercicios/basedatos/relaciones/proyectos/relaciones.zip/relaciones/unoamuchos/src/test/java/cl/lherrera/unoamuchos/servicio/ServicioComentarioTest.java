package cl.lherrera.unoamuchos.servicio;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.time.Instant;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.logging.Logger;

import cl.lherrera.unoamuchos.dto.ComentarioDTO;
import cl.lherrera.unoamuchos.modelo.Usuario;

@DisplayName("Prueba de los servicios de la persona")
public class ServicioComentarioTest {
	private static Logger logger = Logger.getLogger(ServicioComentarioTest.class.getName());
	ServicioComentario servicio = new ServicioComentario();
	
	@BeforeEach
	void porCada() {
		logger.info("Nuevo test___________________________________________________________________");
	}
	
	@Test
	@DisplayName("traer los comentariois de un usuario")
	void comentariosUsuarios() {
		// obtener los comentarios de un usuario
		Usuario luis = new Usuario(1, "luis", null); // estos datos deben estar en la base de datos
		List<ComentarioDTO> comentarios = servicio.obtenerComentariosPorUsuario(luis);
		// listarlos
		comentarios.forEach(comentariodto -> logger.info(comentariodto.toString()));
		// realizar el assert
		assertEquals(2, comentarios.size());
	}
	
	@Test
	@DisplayName("prueba de ingreso de comentario")
	void ingresoDeComentario() {
		// se crea un comentario DTO por que viene del front
		ComentarioDTO dtoComentario = new ComentarioDTO(Date.from(Instant.now()), "luis", "otro comentario");
		// se llama al servicio que ingresa
		int idComentario = servicio.ingresarComentario(dtoComentario);
		// listar
		Usuario luis = new Usuario(1, "luis", null); 
		List<ComentarioDTO> comentarios = servicio.obtenerComentariosPorUsuario(luis);
		comentarios.forEach(comentariodto -> logger.info(comentariodto.toString()));
		
		assertTrue(idComentario > 0);
		
	}
}
