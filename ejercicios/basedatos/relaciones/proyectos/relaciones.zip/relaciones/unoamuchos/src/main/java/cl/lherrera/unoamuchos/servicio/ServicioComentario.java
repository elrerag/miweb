package cl.lherrera.unoamuchos.servicio;

import java.util.ArrayList;
import java.util.List;

import cl.lherrera.unoamuchos.dao.ComentarioDAO;
import cl.lherrera.unoamuchos.dao.UsuarioDAO;
import cl.lherrera.unoamuchos.dto.ComentarioDTO;
import cl.lherrera.unoamuchos.modelo.Comentario;
import cl.lherrera.unoamuchos.modelo.Usuario;


public class ServicioComentario {
	private ComentarioDAO daoComentario = new ComentarioDAO();
	private UsuarioDAO daoUsuario = new UsuarioDAO();
	
	public List<ComentarioDTO> obtenerComentariosPorUsuario(Usuario usuario){
		List<ComentarioDTO> dtoComentarios = new ArrayList<>();
		List<Comentario> comentarios = daoComentario.obtenerComentariosPorUsuario(usuario);
		
		comentarios.forEach(comentario -> {
			ComentarioDTO dtoComentario = new ComentarioDTO(
			comentario.getFecha(),
			comentario.getTexto(),
			comentario.getUsuario().getNombre()
			);
			dtoComentarios.add(dtoComentario);
		});
		
		return dtoComentarios;
	}
	
	public int ingresarComentario(ComentarioDTO dtoComentario) {
		Usuario usuario = daoUsuario.obtenerPorNombre(dtoComentario.getNombreUsuario());
		Comentario comentario = new Comentario();
		
		comentario.setFecha(dtoComentario.getFecha());
		comentario.setTexto(dtoComentario.getComentario());
		comentario.setUsuario(usuario);


		return daoComentario.ingresar(comentario);
	}
}
