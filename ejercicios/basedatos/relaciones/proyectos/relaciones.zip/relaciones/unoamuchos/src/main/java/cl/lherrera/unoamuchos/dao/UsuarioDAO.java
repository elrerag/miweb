package cl.lherrera.unoamuchos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Logger;

import cl.lherrera.unoamuchos.modelo.Usuario;

public class UsuarioDAO {
	private static Logger logger = Logger.getLogger(UsuarioDAO.class.getName());
	private static ManejaConexion mc = ManejaConexion.obtenerManejo();

	public Usuario obtenerPorNombre(String nombre) {
		Usuario usuario = new Usuario();
		String sqlTxt = "select id, nombre from usuario where nombre = '" + nombre + "'";

		try (Connection conexion = mc.obtenerConexion();
				PreparedStatement ps = conexion.prepareStatement(sqlTxt);
				ResultSet rs = ps.executeQuery();) {
			while (rs.next()) {
				usuario.setId(rs.getInt("id"));
				usuario.setNombre(rs.getString("nombre"));
			}
		} catch (SQLException e) {
			logger.severe(sqlTxt);
			logger.info(e.getMessage());
		}

		return usuario;
	}
}
