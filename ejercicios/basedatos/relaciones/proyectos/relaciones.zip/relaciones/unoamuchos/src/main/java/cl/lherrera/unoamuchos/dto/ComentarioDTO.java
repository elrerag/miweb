package cl.lherrera.unoamuchos.dto;

import java.io.Serializable;
import java.util.Date;

public class ComentarioDTO implements Serializable{
	
	private static final long serialVersionUID = -5148123916338477059L;

	private Date fecha;
	private String nombreUsuario;
	private String comentario;

	public ComentarioDTO() {}
	
	public ComentarioDTO(Date fecha, String nombreUsuario, String comentario) {
		this.fecha = fecha;
		this.nombreUsuario = nombreUsuario;
		this.comentario = comentario;
	}
	
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public String getNombreUsuario() {
		return nombreUsuario;
	}
	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}
	public String getComentario() {
		return comentario;
	}
	public void setComentario(String comentario) {
		this.comentario = comentario;
	}
	@Override
	public String toString() {
		return "ComentarioDTO [fecha=" + fecha + ", nombreUsuario=" + nombreUsuario + ", comentario=" + comentario
				+ "]";
	}
	
}
