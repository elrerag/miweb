package cl.lherrera.unoamuchos.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import java.util.logging.Logger;

import cl.lherrera.unoamuchos.modelo.Comentario;
import cl.lherrera.unoamuchos.modelo.Usuario;
import cl.lherrera.unoamuchos.utils.Parsers;

public class ComentarioDAO {
	private static Logger logger = Logger.getLogger(ComentarioDAO.class.getName());
	private static ManejaConexion mc = ManejaConexion.obtenerManejo();
	
	private int retornaIdAutoincrementado(PreparedStatement ps) {
		int idIngresado = 0;

		try (ResultSet rs = ps.getGeneratedKeys();) {
			if (rs.next()) {
				idIngresado = rs.getInt(1);
			}
		} catch (SQLException e) {
			logger.severe(e.getMessage());
		}
		return idIngresado;
	}
	
	public int ingresar(Comentario comentario) {
        int idIngresado = 0;

        String sqlQuery = ""
        		+ "INSERT INTO comentario (fecha, texto, usuario_id) "
        		+ "VALUES (?, ?, ?)";
        
       try(
           Connection conexion = mc.obtenerConexion();
           PreparedStatement ps = conexion.prepareStatement(sqlQuery, Statement.RETURN_GENERATED_KEYS);
    	   
       ){
    	   // para la base de datos se va sqlelemente formateado.
           ps.setDate(1, Parsers.toFechaDb(comentario.getFecha()));
           ps.setString(2, comentario.getTexto());
           ps.setInt(3, comentario.getUsuario().getId());

           int filasAfectadas = ps.executeUpdate();
           // para llamar a esta función el ps debe estar ejecutado
           // o retorna cero.
           idIngresado = retornaIdAutoincrementado(ps);
           

           if(filasAfectadas != 1 || idIngresado == 0)
               throw new SQLException("Error al insertar registro");

       }catch (SQLException e) {
           logger.severe(e.getMessage());
       }

       return idIngresado;
   }
	
	public List<Comentario> obtenerComentariosPorUsuario(Usuario usuario){
		List<Comentario> comentarios = new ArrayList<>();
		
		String sqlTxt = "" 
				+ "select id, fecha, texto, usuario_id "
				+ "from comentario "
				+ "where usuario_id = " + usuario.getId();
		
		try(
				Connection conexion = mc.obtenerConexion();
				PreparedStatement ps = conexion.prepareStatement(sqlTxt);
				ResultSet rs = ps.executeQuery();
		){
			while(rs.next()) {
				SimpleDateFormat formato = new SimpleDateFormat("yyyy-MM-dd hh-mm");
				Date fecha = formato.parse(rs.getString("fecha"));
				
				Comentario comentario = new Comentario(
						rs.getInt("id"),
						fecha,
						rs.getString("texto"),
						usuario);

				comentarios.add(comentario);				
			}
			
		}catch(SQLException | ParseException e) {
			logger.info(e.getMessage());
		}
		
		return comentarios;
	}

}
