package cl.lherrera.unoauno.servicios;

import java.util.ArrayList;
import java.util.List;

import cl.lherrera.unoauno.dao.DatoPersonalDAO;
import cl.lherrera.unoauno.dao.PersonaDAO;
import cl.lherrera.unoauno.dto.PersonaDTO;
import cl.lherrera.unoauno.modelo.DatoPersonal;
import cl.lherrera.unoauno.modelo.Persona;

public class ServicioPersonas {
	DatoPersonalDAO daodatospersonales = new DatoPersonalDAO();
	PersonaDAO daoPersona = new PersonaDAO();
	DatoPersonalDAO daoDatoPersonal = new DatoPersonalDAO();
	
	public List<PersonaDTO> obtenerPersonas(){
		List<PersonaDTO> personasDTO = new ArrayList<>();
		List<DatoPersonal> datosPersonales = daodatospersonales.obtenerTodos();
		
		datosPersonales.forEach(datoPersonal -> {
			PersonaDTO dtoPersona = new PersonaDTO();
			dtoPersona.setNombre(datoPersonal.getPersona().getNombre());
			dtoPersona.setTelefono(datoPersonal.getTelefono());
			dtoPersona.setEmail(datoPersonal.getEmail());
			
			personasDTO.add(dtoPersona);
		});
		
		return personasDTO;
	}
	
	public boolean ingresarPersona(PersonaDTO dtoPersona) {
		boolean ingresado = false;
		Persona persona = new Persona();
		DatoPersonal datosPersonal = new DatoPersonal();

		// ingresar persona
		persona.setNombre(dtoPersona.getNombre());
		int idPersona = daoPersona.ingresar(persona);
		// ya sabemos el id de la persona nueva y lo seteamos
		// para que viaje a ser insertado en sus datos personales.
		persona.setId(idPersona); 

		// ingresar datos personales
		datosPersonal.setTelefono(dtoPersona.getTelefono());
		datosPersonal.setEmail(dtoPersona.getEmail());
		datosPersonal.setPersona(persona);
		
		int idDatoPersonal = daoDatoPersonal.ingresar(datosPersonal);
		
		ingresado = idPersona != 0 && idDatoPersonal != 0;
		
		return ingresado;
	}

}
