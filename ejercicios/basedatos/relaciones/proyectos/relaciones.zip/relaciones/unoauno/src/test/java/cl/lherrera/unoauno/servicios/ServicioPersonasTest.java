package cl.lherrera.unoauno.servicios;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;
import java.util.logging.Logger;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import cl.lherrera.unoauno.dto.PersonaDTO;

@DisplayName("pruebas de servicios personas")
public class ServicioPersonasTest {
	Logger logger = Logger.getLogger(ServicioPersonasTest.class.getName());
	ServicioPersonas servicio = new ServicioPersonas();
	
	@Test
	@DisplayName("prueba listar personas")
	void listarPersonas() {
		// traer las personas desde el servicio
		List<PersonaDTO> personas = servicio.obtenerPersonas();
		// imprimirlas
		personas.forEach(persona -> logger.info(persona.toString()));
		// hacer el assert
		assertEquals(2, personas.size());
	}
	
	@Test
	@DisplayName("probar el ingreso de la persona")
	void servicioIngreso() {
		// simular un ingreso desde la vista
		PersonaDTO dtoPersona = new PersonaDTO("Alejandra", "647874334", "theAlexx@hotmail.com");
		// llamar al servicio de ingreso
		boolean ingresado = servicio.ingresarPersona(dtoPersona);
		// listar las personas
		List<PersonaDTO> personas = servicio.obtenerPersonas();
		personas.forEach(persona -> logger.info(persona.toString()));
		// hacer el assert
		assertEquals(true, ingresado);
	}

}
