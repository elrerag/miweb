package cl.lherrera.relaciones.servicios;

import java.util.List;

import cl.lherrera.relaciones.dao.AlumnoCursoDAO;
import cl.lherrera.relaciones.modelo.Alumno;
import cl.lherrera.relaciones.modelo.AlumnoCurso;
import cl.lherrera.relaciones.modelo.Curso;

public class ServicioMatricula {
	private AlumnoCursoDAO daoAlumnoCurso = new AlumnoCursoDAO();

	public boolean hacerMatricula(AlumnoCurso alumnoCurso) {
		boolean retorno = false;
		int filasAfectadas = 0;
		if(alumnoCurso != null)
			filasAfectadas = daoAlumnoCurso.ingresaAlumnoCurso(alumnoCurso);
		if(filasAfectadas > 0 )
			retorno = true;

		return retorno;
	}
	
	/**
	 * No importa que por ahora esto parezca redundante, pero de esta
	 * manera separamos la lógica de negocio de los accesos a los datos
	 * la lógica de negocio puede cambiar, quizás ya no importa que
	 * tenga una lista de cursos, pero el curso debe seguir
	 * retornando los objetos cursos, esto no puede cambiar
	 * la lógica de negocio sí.
	 *  
	 */
	public List<Alumno> obtenerAlumnosPorCurso(Curso curso) {
		return curso.obtenerAlumnos();
	}
	
	public List<Curso> obtenerCursosPorAlumno(Alumno alumno) {
		return alumno.obtenerCursos();
	}

}
