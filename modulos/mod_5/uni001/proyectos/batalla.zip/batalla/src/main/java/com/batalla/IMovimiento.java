package com.batalla;

public interface IMovimiento {
	void avanzar();
	void derecha();
	void izquierda();
	void retroceder();
}
