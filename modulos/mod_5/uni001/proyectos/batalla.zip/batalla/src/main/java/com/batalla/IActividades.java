package com.batalla;

public interface IActividades {
	void ataqueBasico();
	void ataqueAvanzado();
	void defenderAtaque();
	void esquivarAtaque();
}
