package cl.lherrera.m5u3l2001.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@SequenceGenerator(
		name="SQ_USUARIO", 
		initialValue=1, 
		allocationSize=1,
		sequenceName = "SQ_USUARIO") // esta es la secuencia que se crea en la base de datos (mismo nombre)

@Data // setters & getters
@NoArgsConstructor // constructor sin argumentos.
@AllArgsConstructor // constructor con todos los argumentos.
@Table(name="usuario") // nombre de la tabla en en caso que la clase no se llame como la tabla
public class Usuario {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SQ_USUARIO")
	private Integer idUsuario;
	// solo a modo de ejemplo, en el caso que la columna en la base 
	// de datos sea diferente. En este caso son el mismo nombre
	// pero no siempre esto debe ser así.
	@Column(name="nombre") 
	private String nombre;
	private String clave;
	private Integer rut;
	private String dv;

}
