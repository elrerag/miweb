package cl.lherrera.m5u3l2001;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class M5u3l2001Application {

	public static void main(String[] args) {
		SpringApplication.run(M5u3l2001Application.class, args);
	}

}
