package cl.lherrera.m5u3l2001.services;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.lherrera.m5u3l2001.entity.Usuario;
import cl.lherrera.m5u3l2001.repositories.UsuarioRepository;
import cl.lherrera.m5u3l2001.vos.UsuarioVO;

@Service
public class UsuarioServiceImpl implements UsuarioService {
	private static Logger logger = LoggerFactory.getLogger(UsuarioServiceImpl.class.getName());

	@Autowired
	private UsuarioRepository daoUsuario;
	

	public UsuarioVO ObtenerUsuarioPorNombreYClave(String nombre, String clave) {
		UsuarioVO usuarioVO = new UsuarioVO("Ha ocurrido un error", "102");
		try {
			Usuario usuario = daoUsuario.findOneByNombreAndClave(nombre, clave).orElse(null);
			
			usuarioVO.setUsuario(usuario);

			usuarioVO.setMensaje(String.format("Se ha/n encontrado %d registro/s", usuarioVO.getUsuarios().size()));
			usuarioVO.setCodigo("0");
		} catch (Exception e) {
			logger.trace("Usuario Service: Error en getAllUsuarios", e);
		}
		
		return usuarioVO;
	}

	@Override
	@Transactional(readOnly = true)
	public UsuarioVO ObtenerTodosLosUsuarios() {
		UsuarioVO usuarioVO = new UsuarioVO("Ha ocurrido un error", "102");
		try {
			usuarioVO.setUsuarios((List<Usuario>) daoUsuario.findAll());
			usuarioVO.setMensaje(String.format("Se ha/n encontrado %d registro/s", usuarioVO.getUsuarios().size()));
			usuarioVO.setCodigo("0");
		} catch (Exception e) {
			logger.trace("Usuario Service: Error en getAllUsuarios", e);
		}
		return usuarioVO;
	}

	@Override
	@Transactional
	public UsuarioVO ingresarUsuario(UsuarioVO usuarioVO) {
		UsuarioVO voUsuarioResp = new UsuarioVO("Ha ocurrido un error", "104");
		try {
			Usuario usuario = daoUsuario.save(usuarioVO.getFirst());

			voUsuarioResp.setMensaje(
					usuario != null ? "Se ha creado el usuario correctamente" : "No se ha podido crear el usuario");
			voUsuarioResp.setCodigo(usuario != null ? "0" : "104");
		} catch (Exception e) {
			logger.trace("Usuario Service: Error en add", e);
		}
		return voUsuarioResp;
	}

	@Override
	@Transactional
	public UsuarioVO actualizarUsuario(UsuarioVO usuarioVO) {
		UsuarioVO respuesta = new UsuarioVO("Ha ocurrido un error", "105");
		try {
			Usuario usuario = daoUsuario.save(usuarioVO.getFirst());
			if (usuario != null) {
				respuesta.setMensaje(String.format("Se ha/n actualizado correctamente %s usuario/s", usuario.getNombre()));
				respuesta.setCodigo("0");
			}
		} catch (Exception e) {
			logger.trace("Usuario Service: Error en update", e);
		}
		return respuesta;
	}

	@Override
	@Transactional
	public UsuarioVO eliminarUsuario(UsuarioVO usuarioVO) {
		usuarioVO.setMensaje("Ha ocurrido un error");
		usuarioVO.setCodigo("106");

		try {
			daoUsuario.delete(usuarioVO.getFirst());
			usuarioVO.setMensaje(String.format("Se ha/n eliminado correctamente a %s usuario/s", usuarioVO.getFirst().getNombre()));

			usuarioVO.setCodigo("0");
		} catch (Exception e) {
			logger.trace("Usuario Service: Error en delete", e);
		}
		return usuarioVO;
	}

}
