package cl.lherrera.m5u3l2001.services;


import cl.lherrera.m5u3l2001.vos.UsuarioVO;

public interface UsuarioService {
	
	UsuarioVO ObtenerUsuarioPorNombreYClave(String nombre, String clave);

	UsuarioVO ObtenerTodosLosUsuarios();
	
	UsuarioVO ingresarUsuario(UsuarioVO usuarioVO);
	
	UsuarioVO actualizarUsuario(UsuarioVO usuarioVO);
	
	UsuarioVO eliminarUsuario(UsuarioVO usuarioVO);
}
