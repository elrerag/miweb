package cl.lherrera.m5u3l2001.repositories;


import java.util.Optional;

import org.springframework.data.repository.CrudRepository;

import cl.lherrera.m5u3l2001.entity.Usuario;

// con sólo esto ya tenemos el CRUD
public interface UsuarioRepository extends CrudRepository<Usuario, Integer> {
	
	public Optional<Usuario> findOneByNombreAndClave(String nombre, String clave);
}
