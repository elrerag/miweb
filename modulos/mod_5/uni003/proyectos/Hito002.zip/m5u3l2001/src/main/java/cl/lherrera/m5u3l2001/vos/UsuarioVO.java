package cl.lherrera.m5u3l2001.vos;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cl.lherrera.m5u3l2001.entity.Usuario;
import lombok.Data;
import lombok.NoArgsConstructor;

// instalar lombok con el ide cerrado
// https://stackoverflow.com/questions/52780535/lombok-with-spring-tool-suite-4
// si no funciona implementar los códigos no perder el tiempo
// si no funciona, aunque en mac es con el ini en windows es con exe especificar 
// donde esté instalado

// https://www.wandercosta.com/lombok-constructors/

@Data
@NoArgsConstructor
public class UsuarioVO {
	private List<Usuario> usuarios = new ArrayList<>();
	private String mensaje;
	private String codigo;
	
	private static Logger logger = LoggerFactory.getLogger(UsuarioVO.class.getName());
	
	public UsuarioVO(String mensaje, String codigo) {
		this.mensaje = mensaje;
		this.codigo = codigo;
	}

	/**
	 * Ingresa un usuario para aquellos métodos
	 * que solo necesitan ingresar un usuario
	 * y no una lista.
	 */
	public Usuario setUsuario(Usuario usuario) {
		if(usuarios.size() > 0) {
			logger.warn("Advertencia: La lista de usuarios ya existe: " + usuarios.toString());
		}else {
			usuarios.add(usuario);
		}
		
		return usuario;
	}

	/**
	 * Retorna el primer usuario de la lista que fue ingresado.
	 * Es útil solamente cuando sabemos que hay un solo elemento
	 */
	public Usuario getFirst() {
		if(usuarios.size() > 1)
			logger.warn("Advertencia: El arreglo posee más de un elemento");
		
		return usuarios.get(0);
	}

}
