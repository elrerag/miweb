package cl.lherrera.m5u3l2001;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M5u3l2001ApplicationTests {

	@Test
	void contextLoads() {
	}

}
