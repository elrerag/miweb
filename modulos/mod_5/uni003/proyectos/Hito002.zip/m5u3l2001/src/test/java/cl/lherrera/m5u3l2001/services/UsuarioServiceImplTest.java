package cl.lherrera.m5u3l2001.services;

import static org.junit.jupiter.api.Assertions.assertTrue;


import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import cl.lherrera.m5u3l2001.entity.Usuario;
import cl.lherrera.m5u3l2001.services.UsuarioServiceImpl;
import cl.lherrera.m5u3l2001.vos.UsuarioVO;

@SpringBootTest
@DisplayName("Prueba de servicios")
public class UsuarioServiceImplTest {
	private Logger logger = LoggerFactory.getLogger(UsuarioServiceImplTest.class.getName());

	@Autowired
	UsuarioServiceImpl servicio;

	@Test
    @DisplayName("Traer todos los usuarios")
    public void prueba001() {
        // guadamos en una lista los usuarios
        UsuarioVO usuarioVO = servicio.ObtenerTodosLosUsuarios();
        // deben existir 2 usuarios en la base de datos
        assertTrue(usuarioVO.getUsuarios().size() >= 2);
    }

    @Test
    @DisplayName("Probar ingresar usuario")
    public void prueba002() {
        // creamos un usuario
        Usuario usuario = new Usuario();
        usuario.setNombre("test1");
        usuario.setClave("clave1");
        // cargamos el usuario en el VO
        UsuarioVO usuarioVO = new UsuarioVO();
        usuarioVO.setUsuario(usuario);
        // ingresamos el usuario con el servicio
        UsuarioVO respuesta = servicio.ingresarUsuario(usuarioVO);

        assertTrue(respuesta.getMensaje().contains("Se ha creado el usuario correctamente"));

    }

    @Test
    @DisplayName("Prueba servicio update")
    public void prueba003() {
        // llamamos al usuario
        UsuarioVO usuarioVO = servicio.ObtenerUsuarioPorNombreYClave("test1", "clave1");
        // cambiamos un valor
        usuarioVO.getFirst().setNombre("test2");
        usuarioVO = servicio.actualizarUsuario(usuarioVO);
        // comprobamos con mensaje retornado del servicio
        assertTrue(usuarioVO.getMensaje().contains("actualizado correctamente"));
    }

    @Test
    @DisplayName("Prueba de eliminado")
    public void prueba004() {
        // se busca el usuario
    	UsuarioVO usuarioVO = servicio.ObtenerUsuarioPorNombreYClave("test2", "clave1");

    	usuarioVO = servicio.eliminarUsuario(usuarioVO);
    	logger.info(usuarioVO.getMensaje());
        assertTrue(usuarioVO.getMensaje().contains("eliminado correctamente"));
    }

}
