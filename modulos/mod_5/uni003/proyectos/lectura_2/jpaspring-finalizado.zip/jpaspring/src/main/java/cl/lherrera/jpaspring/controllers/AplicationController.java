package cl.lherrera.jpaspring.controllers;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import cl.lherrera.jpaspring.entities.Usuario;
import cl.lherrera.jpaspring.services.AutentificacionServicio;
import cl.lherrera.jpaspring.services.PersonaServiceImpl;
import cl.lherrera.jpaspring.services.UsuarioServiceImpl;


@Controller
public class AplicationController {
	private static final Logger logger = LoggerFactory.getLogger(AplicationController.class);

	@Autowired
	AutentificacionServicio authService;
	
	@Autowired
	PersonaServiceImpl servicioPersona;
	
	@Autowired
	UsuarioServiceImpl servicioUsuario;
	
	@GetMapping("/")
	public String home(Model modelo) {
		logger.info("llamada a : '/'");

		
		if(!authService.estaLogueado()) {
			return "auth/login";
		}else {
			Usuario authUsuario = authService.obtenerUsuarioLogeado();
			modelo.addAttribute("authUsuario", authUsuario);
		}
		
		return "index";
	}

}
