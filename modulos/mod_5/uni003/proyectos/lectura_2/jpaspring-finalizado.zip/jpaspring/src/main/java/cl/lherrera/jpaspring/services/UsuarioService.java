package cl.lherrera.jpaspring.services;

import cl.lherrera.jpaspring.entities.Usuario;

public interface UsuarioService {
	void ingresarUsuario(Usuario usuario);
}
