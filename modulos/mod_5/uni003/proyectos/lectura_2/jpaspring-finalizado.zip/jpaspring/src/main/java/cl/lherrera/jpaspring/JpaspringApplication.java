package cl.lherrera.jpaspring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

import cl.lherrera.jpaspring.entities.Usuario;
import cl.lherrera.jpaspring.services.UsuarioServiceImpl;


@SpringBootApplication
public class JpaspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaspringApplication.class, args);
	}

}

/**
 *	Este método, realiza acciones antes que la aplicación está en ejecución
 *	así, el usuario está ingresado antes de iniciar sesión. 
 *
 */
@Component
class SeEjecutaAntes implements CommandLineRunner{
	
	@Autowired
	UsuarioServiceImpl servicioUsuario;

	@Override
	public void run(String... args) throws Exception {
		// para probar con este usuario al menos
		Usuario usuarioPueba = new Usuario();
		usuarioPueba.setNombre("Luis herrera");
		usuarioPueba.setEmail("l.herrera.garnica@gmail.com");
		usuarioPueba.setContrasenia("1234");
		
		
		servicioUsuario.ingresarUsuario(usuarioPueba);
		// para probar con este usuario al menos ##
		
	}
	
}
