package cl.lherrera.jpaspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
