package cl.lherrera.jpaspring.services;

import cl.lherrera.jpaspring.entities.Usuario;

public interface AutentificacionServicio {

	Boolean estaLogueado();

	Usuario obtenerUsuarioLogeado();

	Usuario ingresarAlSistema(Usuario usuario);
	
	void sairDelSistema();
}
