package cl.lherrera.jpaspring.repositories;

import java.util.Optional;

import cl.lherrera.jpaspring.entities.Usuario;

public interface UsuarioRepo extends PersonaRepo{

	Optional<Usuario> findOneByEmailAndContrasenia(String email, String contrasenia);

}
