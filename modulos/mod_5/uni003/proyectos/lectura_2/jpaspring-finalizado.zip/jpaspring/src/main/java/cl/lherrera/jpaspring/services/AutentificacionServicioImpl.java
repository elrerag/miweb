package cl.lherrera.jpaspring.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.context.annotation.SessionScope;

import cl.lherrera.jpaspring.entities.Usuario;
import cl.lherrera.jpaspring.repositories.UsuarioRepo;


@Service
@SessionScope
public class AutentificacionServicioImpl implements AutentificacionServicio {

	@Autowired
	private UsuarioRepo usuarioRepo;
	
	private Usuario usuarioAutent;

	@Override
	public Boolean estaLogueado() {
		return usuarioAutent != null;
	}

	@Override
	public Usuario obtenerUsuarioLogeado() {
		return usuarioAutent;
	}

	@Override
	public Usuario ingresarAlSistema(Usuario usuario) {
		usuarioAutent = usuarioRepo.findOneByEmailAndContrasenia(
			usuario.getEmail(), 
			usuario.getContrasenia())
		.orElse(null);

		return usuarioAutent;
	}

	@Override
	public void sairDelSistema() {
		usuarioAutent = null;
	}

}
