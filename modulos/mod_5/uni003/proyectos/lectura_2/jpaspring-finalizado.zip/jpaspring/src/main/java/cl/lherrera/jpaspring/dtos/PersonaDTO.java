package cl.lherrera.jpaspring.dtos;

import java.util.List;

import cl.lherrera.jpaspring.entities.Persona;

public class PersonaDTO {

	private List<Persona> personas;
	private List<Integer> paginas;
	private Integer paginaActual;

	public List<Persona> getPersonas() {
		return personas;
	}

	public void setPersonas(List<Persona> personas) {
		this.personas = personas;
	}

	public List<Integer> getPaginas() {
		return paginas;
	}

	public void setPaginas(List<Integer> paginas) {
		this.paginas = paginas;
	}

	public Integer getPaginaActual() {
		return paginaActual;
	}

	public void setPaginaActual(Integer paginaActual) {
		this.paginaActual = paginaActual;
	}

	@Override
	public String toString() {
		return "PersonaDTO [personas=" + personas + ", paginas=" + paginas + ", paginaActual=" + paginaActual + "]";
	}

}
