package cl.lherrera.jpaspring.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.lherrera.jpaspring.entities.Usuario;
import cl.lherrera.jpaspring.repositories.UsuarioRepo;

@Service
public class UsuarioServiceImpl implements UsuarioService {
	@Autowired
	UsuarioRepo repo;

	@Override
	public void ingresarUsuario(Usuario usuario) {
		repo.save(usuario);
	}
}
