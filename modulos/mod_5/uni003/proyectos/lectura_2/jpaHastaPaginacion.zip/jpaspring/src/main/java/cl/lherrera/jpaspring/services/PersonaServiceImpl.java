package cl.lherrera.jpaspring.services;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.criteria.Order;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cl.lherrera.jpaspring.dtos.PersonaDTO;
import cl.lherrera.jpaspring.entities.Persona;
import cl.lherrera.jpaspring.repositories.PersonaRepo;

@Service
public class PersonaServiceImpl implements PersonaService{
	private static final Logger logger = LoggerFactory.getLogger(PersonaServiceImpl.class.getName());
	
	@Autowired
	PersonaRepo repo;
	

	@Override
	@Transactional(readOnly = true)
	public List<Persona> obtenerPersonas() {
		return (List<Persona>) repo.findAll();
	}

	@Override
	@Transactional(readOnly = true)
	public List<Persona> obtenerPersonasPorNombre(String nombre) {
		
		return repo.findAllByNombre(nombre);
	}

	@Override
	@Transactional(readOnly = true)
	public Persona encontrarPersona(Integer id) {
		// así nos evitamos un null pointer exception
		return repo.findById(id).orElse(new Persona());
	}

	@Override
	@Transactional
	public Persona eliminarPersona(Persona persona) {
		int numeroQueAunNoSeOcupa = repo.myDeleteById(persona.getId());
		return persona;
	}

	@Override
	@Transactional
	public Persona actualizarPersona(Persona persona) {
		return repo.save(persona);
	}

	@Override
	@Transactional
	public Persona IngresarPersona(Persona persona) {		
		return repo.save(persona);
	}
	
	@Override
	public PersonaDTO obtenerPersonasPaginadas(Integer pagina, Integer cantidad) {
		logger.info("Num Pagina: " + pagina);
		PersonaDTO personaDTO = new PersonaDTO();
		// comienza en cero, para que con la página 1
		// busque en la página 0 y lo retorne como página 1.
		
		
		Pageable paginado = PageRequest.of(pagina - 1, 2, Sort.by("id").ascending());
		// consulta a la base
		Page<Persona> personaPaginas = repo.findAll(paginado);
		
		logger.info(personaPaginas.getContent().toString());
		
		// ingreso de personas al DTO
		personaDTO.setPersonas(personaPaginas.getContent());
		// ingresamos el número de página actual
		// el getNumber nos entrega un cero en caso de ser la primera página
		// el argumento pagina, viene desde el front con el click
		// que se hace y llegará fielmente el verdadero número a buscar
		// el único aproblemado con esto es el PageRequest.of(pagina... ya que
		// él busca por el número consultado menos uno.
		personaDTO.setPaginaActual(pagina);
		// llenamos la lista de números del paginador
		List<Integer> paginas = new ArrayList<>();
		for(int i = 0; i < personaPaginas.getTotalPages(); i ++)
			paginas.add(i + 1);
		
		personaDTO.setPaginas(paginas);
		logger.info("personaDTO: " + personaDTO.toString());
		return personaDTO;
	}

	
}
