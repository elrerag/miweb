package cl.lherrera.jpaspring.services;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import cl.lherrera.jpaspring.entities.Persona;
import cl.lherrera.jpaspring.repositories.PersonaRepo;

@SpringBootTest
public class PersonaServiceTest {

	@Autowired
	PersonaService servicio;
	
	@MockBean
	PersonaRepo mockRepo;

	@Test
	@DisplayName("Buscar personas por nombre")
	public void prueba005() {
		// crear la persona en la base mockdatos
		List<Persona> personas = new ArrayList<>();
		personas.add(new Persona(1, "luis"));
		personas.add(new Persona(2, "luis"));

		when(mockRepo.findAllByNombre("luis")).thenReturn(personas);
		
		
		// comprobamos la persona
		assertThat(personas).isEqualTo(servicio.obtenerPersonasPorNombre("luis"));
	}
	
	@Test
	@DisplayName("obtener una lista de las personas")
	public void prueba004() {
		// una lista de personas
		List<Persona> personas = new ArrayList<>();
		personas.add(new Persona(1, "luis"));
		personas.add(new Persona(2, "ana"));
		// simular petición en la base de datos
		when((List<Persona>)mockRepo.findAll()).thenReturn(personas);
		
		assertThat(personas).isEqualTo(servicio.obtenerPersonas());
		
	}
	
	@Test
	@DisplayName("almacenar persona")
	public void prueba001() {
		// creamos el dato en memoria
		Persona persona = new Persona(1, "luis");
		// simulación de dato en la base de datos
		when(mockRepo.save(persona)).thenReturn(persona);
		// funcionamiento del servicio. (se ejecuta el mockRepo y no
		// el repo que está en su clase, el que llama a 
		// la base datos así esta petición
		// se simula sin escribir
		// realmente en la BD
		assertThat(servicio.IngresarPersona(persona)).isEqualTo(persona);
	}
	
	@Test
	@DisplayName("actualizar una persona")
	public void prueba002() {
		// creamos la persona
		Persona persona = new Persona(1, "Luis");
		// se simula persona encontrada
		when(mockRepo.findById(1)).thenReturn(Optional.of(persona));
		Persona personaUdt = servicio.encontrarPersona(1);
		// se actualiza el valor. se puede ver que la primera simulación
		// tuvo efecto, el mockRepo actuó como el repositorio
		// oficial ya que usamos el servicio para traer
		// la persona usando el servicio.
		personaUdt.setNombre("Ana");
		
		// simulación de actualización (es el repo el que simulamos y 
		// save(cuando existe actualiza o crea)
		when(mockRepo.save(personaUdt)).thenReturn(personaUdt);
		
		assertThat(servicio.actualizarPersona(personaUdt).getNombre()).isEqualTo("Ana");
		
	}
	
	
	@Test
	@DisplayName("eliminar persona")
	public void prueba003() {
		// encontrar la perosona para eliminarla ya que esta 
		// debe existir en la base de datos.
		when(mockRepo.findById(1))
		.thenReturn(Optional.of(new Persona(1, "luis")));
		// con la base de datos simulada, utlizamos el servicio.
		Persona persona = servicio.encontrarPersona(1);
		// simulamos la interacción de la base de datos 
		when(mockRepo.myDeleteById(1)).thenReturn(1);
		// ocupamos el servicio
		Persona personaEliminada = servicio.eliminarPersona(persona); 
		
		assertThat(personaEliminada.getId()).isEqualTo(persona.getId());
		
	}
	
}
