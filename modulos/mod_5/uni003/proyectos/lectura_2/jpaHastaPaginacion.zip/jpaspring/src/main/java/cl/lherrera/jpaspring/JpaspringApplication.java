package cl.lherrera.jpaspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.boot.CommandLineRunner;



@SpringBootApplication
public class JpaspringApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpaspringApplication.class, args);
	}
	
//	@Bean
//	public CommandLineRunner demo(PersonaServiceImpl servicio) {
//		return (args) -> {
//			 servicio.obtenerPersonasPaginadas(0, 3);
//		};
//	}

}
