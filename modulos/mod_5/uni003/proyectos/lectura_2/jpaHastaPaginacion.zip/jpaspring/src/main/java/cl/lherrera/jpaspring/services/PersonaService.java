package cl.lherrera.jpaspring.services;

import java.util.List;

import cl.lherrera.jpaspring.dtos.PersonaDTO;
import cl.lherrera.jpaspring.entities.Persona;


public interface PersonaService {

	PersonaDTO obtenerPersonasPaginadas(Integer pagina, Integer cantidad);
	List<Persona> obtenerPersonas();
	List<Persona> obtenerPersonasPorNombre(String nombre);
	Persona IngresarPersona(Persona persona);
	Persona encontrarPersona(Integer id);
	Persona eliminarPersona(Persona persona);
	Persona actualizarPersona(Persona persona);
}
