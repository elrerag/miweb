package cl.lherrera.jpaspring.controllers;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import cl.lherrera.jpaspring.dtos.PersonaDTO;
import cl.lherrera.jpaspring.entities.Persona;
import cl.lherrera.jpaspring.services.PersonaService;

@Controller
@RequestMapping("/personas")
public class PersonaController {
	private static final Logger logger = LoggerFactory.getLogger(PersonaController.class);
	private static final Integer FILAS_POR_PAGINA = 3;
	
	@Autowired
	PersonaService servicio;

	@GetMapping("/ingresar")
	@ResponseStatus(code = HttpStatus.OK)
	public String inicio(
			Model modelo, 
			@RequestParam(required = false) Integer pagina) {

		logger.info("Petición: /personas/ingresar");
		// si no viene la página, se simula la primera, el método PageRequest.of(pagina
		// pide que la primera sea cero; pero esto es manejado por el servicio
		// en el controlador sabemos que la primera página es la 1, si esto no es
		// así, el servicio lo debe manejar
		if(pagina == null)
			pagina = 1;
		
		PersonaDTO dtoPersona = servicio.obtenerPersonasPaginadas(pagina, FILAS_POR_PAGINA);

		modelo.addAttribute("dtoPersona", dtoPersona);
		// si no hay más de una página, no es necesario paginar
		modelo.addAttribute("paginar", dtoPersona.getPaginas().size() > 1);
		return "personas/personas";
	}
	
//	@ResponseStatus(code = HttpStatus.CREATED) // con esto no funciona el redirect
	@PostMapping("/ingresar")
	public String ingresar(
			@ModelAttribute("foo") Persona persona,
			@RequestParam String nombre, 
			RedirectAttributes attributes) {
		logger.info("Petición post /ingresar");
		
		// sin usar el retorno aún
		Persona respuesta = servicio.IngresarPersona(persona);
		
		if(persona == null) 
			logger.error("error en ingreso de persona");


		return "redirect:ingresar";
	}
	
	@GetMapping("/actualizar")
	public String actualizar(
			Model modelo, 
			@RequestParam String id) {
		logger.info("Petición-GET: /actualizar");
		
		Persona persona = servicio.encontrarPersona(Integer.parseInt(id));
		modelo.addAttribute("persona", persona);

		return "personas/actualizar";
	}
	
	// el formulario debe estar completo con los names, para que lo
	// reconozca como la misma entidad y no una nueva
	@PostMapping("/actualizar")
	public String doActualizar(@ModelAttribute("foo") Persona persona) {
		logger.info("Petición-POST: /actualizar");
		servicio.actualizarPersona(persona);
		return "redirect:ingresar";
	}
	
	@GetMapping("/eliminar")
	public String eliminar(
			Model modelo, 
			@RequestParam String id) {
		logger.info("Petición-GET: /eliminar");
		Persona persona = servicio.encontrarPersona(Integer.parseInt(id));
		modelo.addAttribute("persona", persona);

		return "personas/eliminar";
	}
	
	@PostMapping("/eliminar")
	public String doEliminar(
			@ModelAttribute("foo") Persona persona,
			@RequestParam String id) {
		logger.info("Petición-POST: /eliminar");
		Persona respuesta = servicio.eliminarPersona(persona);
		if(respuesta == null)
			logger.info("Petición-POST: /eliminar");	

		return "redirect:ingresar";
	}

}
