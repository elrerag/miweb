package cl.lherrera.jpaspring.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import cl.lherrera.jpaspring.entities.Persona;

public interface PersonaRepo 
	extends JpaRepository<Persona, Integer>,
		PagingAndSortingRepository<Persona, Integer> {

	/**
	 * Se puede parecer mucho a una consulta en la base de datos pero es una
	 * consulta al modelo, la respuesta es un @Entity. por eso la "tabla" está en
	 * mayúsculas.
	 * 
	 * Eso es debido a que no renemos un PersonaRepoImpl que maneje la
	 * personalización de esta consulta y como la original delete, retorna void no
	 * es muy buena para hacer test ya que no tenemos contra qué validar si
	 * simulamos la base de datos. 
	 * 
	 * En el fondo es solamente un deleteById(), pero se expone para su ejemplo
	 * Que podemos aplicar queries a las entidades.
	 * 
	 */
	@Modifying
	@Query("DELETE FROM Persona WHERE id = ?1")
	Integer myDeleteById(Integer id);
	
	// no posee un nombre personalizado, cumple con la nomenclatura find
	// debe ir aunque siga la nomenclatura
	List<Persona> findAllByNombre(String nombre);
}
