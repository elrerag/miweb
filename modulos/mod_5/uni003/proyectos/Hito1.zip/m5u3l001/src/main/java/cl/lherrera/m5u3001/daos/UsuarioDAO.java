package cl.lherrera.m5u3001.daos;

import java.util.List;

import cl.lherrera.m5u3001.models.Usuario;

public interface UsuarioDAO {
	
	List<Usuario> getAllUsuarios();
	Usuario findByNombreAndClave(String nombre, String clave);
	
	/* 
	* Nuevos métodos del CRUD 
	*/
	public int add(Usuario usuario); 
	public int update(Usuario usuario); 
	public int delete(Usuario usuario);
}
