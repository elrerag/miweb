package cl.lherrera.m5u3001.mappers;

import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.jdbc.core.RowMapper;

import cl.lherrera.m5u3001.models.Usuario;

public class UsuarioMapper implements RowMapper<Usuario> {

	public Usuario mapRow(ResultSet resultSet, int i) throws SQLException {
		Usuario usuario = new Usuario();
		usuario.setIdUsuario(resultSet.getInt("id_usuario"));
		usuario.setNombre(resultSet.getString("nombre"));
		usuario.setClave(resultSet.getString("clave"));
		usuario.setRut(resultSet.getInt("rut"));
		usuario.setDv(resultSet.getString("dv"));
		return usuario;
	}

}
