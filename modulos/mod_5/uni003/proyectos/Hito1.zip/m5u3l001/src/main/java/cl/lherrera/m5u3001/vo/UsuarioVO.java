package cl.lherrera.m5u3001.vo;

import java.util.List;

import cl.lherrera.m5u3001.models.Usuario;

public class UsuarioVO {
	private List<Usuario> usuarios; 
	private String mensaje; 
	private String codigo;
	
	public UsuarioVO() {}
	
	public UsuarioVO(List<Usuario> usuarios, String mensaje, String codigo) {
		super();
		this.usuarios = usuarios;
		this.mensaje = mensaje;
		this.codigo = codigo;
	}

	public List<Usuario> getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(List<Usuario> usuarios) {
		this.usuarios = usuarios;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	@Override
	public String toString() {
		return "UsuarioVO [mensaje=" + mensaje + ", codigo=" + codigo + "]";
	}
	
}
