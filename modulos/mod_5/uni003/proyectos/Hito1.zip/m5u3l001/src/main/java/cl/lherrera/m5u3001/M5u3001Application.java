package cl.lherrera.m5u3001;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class M5u3001Application {

	public static void main(String[] args) {
		SpringApplication.run(M5u3001Application.class, args);
	}

}
