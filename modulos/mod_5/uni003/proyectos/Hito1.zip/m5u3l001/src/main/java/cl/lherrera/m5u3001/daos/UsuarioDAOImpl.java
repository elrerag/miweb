package cl.lherrera.m5u3001.daos;

import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import cl.lherrera.m5u3001.mappers.UsuarioMapper;
import cl.lherrera.m5u3001.models.Usuario;

@Repository
public class UsuarioDAOImpl implements UsuarioDAO {
	JdbcTemplate jdbcTemplate;

	@Autowired
	public UsuarioDAOImpl(DataSource dataSource) {
		jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public List<Usuario> getAllUsuarios() {
		return jdbcTemplate.query("select * from usuario", new UsuarioMapper());
	}

	public Usuario findByNombreAndClave(String nombre, String clave) {

		// Se utilizan "?" para denotar las posiciónes de los parámetros (límite 1)
		// se limita por que pueden existir varios con el mismo nombre.
		String sqlText = "select * from USUARIO where nombre=? and clave=? and rownum = 1";

		// Esta es la lista que llenará los signos de interrogación de la consulta.
		// Otra utlidad para ahorrar el rs.setString()...
		Object[] parametros = new Object[] { nombre, clave };

		// Se le pasa una implementación de RowMapper<T> (En este caso una de Usuario)
		UsuarioMapper mapaDeUsuario = new UsuarioMapper();

		// el retorno es según el tipo de mapa.
		return jdbcTemplate.queryForObject(sqlText, parametros, mapaDeUsuario);
	}

	// CRUD
	@Override
	public int add(Usuario usuario) {
		return jdbcTemplate.update(
				"insert into usuario values (sq_usuario.nextval, ?, ?, ?, ?)", 
				usuario.getNombre(),
				usuario.getClave(), 
				usuario.getRut(), 
				usuario.getDv()
		);
	}

	@Override
	public int update(Usuario usuario) {
		return jdbcTemplate.update(
				"update usuario set nombre = ?, clave = ?,  rut = ?, dv = ? where id_usuario = ?",
				usuario.getNombre(), 
				usuario.getClave(), 
				usuario.getRut(), 
				usuario.getDv(), 
				usuario.getIdUsuario()
		);
	}

	@Override
	public int delete(Usuario usuario) {
		return jdbcTemplate.update(
				"delete from usuario where id_usuario = ?", 
				usuario.getIdUsuario()
		);
	}

}
