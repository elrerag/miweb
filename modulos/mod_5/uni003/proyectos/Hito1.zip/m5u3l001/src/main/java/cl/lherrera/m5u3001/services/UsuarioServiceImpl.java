package cl.lherrera.m5u3001.services;

import java.util.ArrayList;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import cl.lherrera.m5u3001.daos.UsuarioDAO;
import cl.lherrera.m5u3001.models.Usuario;
import cl.lherrera.m5u3001.vo.UsuarioVO;

@Service
public class UsuarioServiceImpl implements UsuarioService {
	private static Logger logger = LoggerFactory.getLogger(UsuarioServiceImpl.class.getName());

	@Autowired
	private UsuarioDAO daoUsuario;

	@Override
	public UsuarioVO obtenerTodosLosUsuarios() {
		UsuarioVO voUsuario = new UsuarioVO(new ArrayList<Usuario>(), "Ha ocurrido un error", "102");

		try {
			voUsuario.setUsuarios(new ArrayList<>(daoUsuario.getAllUsuarios()));
			voUsuario.setMensaje(String.format("Se ha/n encontrado %d registro/s", voUsuario.getUsuarios().size()));

			voUsuario.setCodigo("0");
		} catch (Exception e) {
			logger.trace("Usuario Service: Error en getAllUsuarios", e);
		}
		return voUsuario;
	}

	@Override
	public UsuarioVO obtenerUsuarioPorNombreYClave(String nombre, String clave) {
		UsuarioVO voUsuario = new UsuarioVO(new ArrayList<Usuario>(), "Ha ocurrido un error", "101");
		try {
			Usuario usuario = daoUsuario.findByNombreAndClave(nombre, clave);
			voUsuario.getUsuarios().add(usuario);
			voUsuario.setMensaje(String.format("Se ha/n encontrado %d registro/s", null != usuario ? 1 : 0));
			voUsuario.setCodigo("0");
		} catch (Exception e) {
			logger.trace("Usuario Service: Error en findByNombreAndClave", e);
		}
		return voUsuario;
	}

	@Override
	public UsuarioVO login(String nombre, String clave) {
		UsuarioVO voUsuario = new UsuarioVO(new ArrayList<Usuario>(), "Credenciales incorrectas", "102");

		boolean credencialesVacias = nombre.length() == 0 || clave.length() == 0;

		if (!credencialesVacias) {
			voUsuario = this.obtenerUsuarioPorNombreYClave(nombre, clave);

			if (voUsuario.getCodigo().equals("0")) {
				voUsuario.setMensaje(String.format("Bienvenido %s", voUsuario.getUsuarios().get(0).getNombre()));
			}
		}

		return voUsuario;
	}

	// Justificando el CRUD

	// UsuarioServiceImpl
	@Override
	public UsuarioVO add(Usuario usuario) {
		UsuarioVO voUsuario = new UsuarioVO(new ArrayList<Usuario>(), "Ha ocurrido un error", "104");
		try {
			int registrosActualizados = daoUsuario.add(usuario);
			voUsuario.setMensaje(registrosActualizados == 1 ? "Se ha creado el usuario correctamente"
					: "No se ha podido crear el usuario");
			voUsuario.setCodigo(registrosActualizados == 1 ? "0" : "104");
		} catch (Exception e) {
			logger.trace("Usuario Service: Error en add", e);
		}
		return voUsuario;
	}

	@Override
	public UsuarioVO update(Usuario usuario) {
		UsuarioVO voUsuario = new UsuarioVO(new ArrayList<Usuario>(), "Ha ocurrido un error", "105");
		try {
			int registrosActualizados = daoUsuario.update(usuario);

			voUsuario
					.setMensaje(String.format("Se ha/n actualizado correctamente %d usuario/s", registrosActualizados));
			voUsuario.setCodigo("0");
		} catch (Exception e) {
			logger.trace("Usuario Service: Error en update", e);
		}
		return voUsuario;
	}

	@Override
	public UsuarioVO delete(Usuario usuario) {
		UsuarioVO voUsuario = new UsuarioVO(new ArrayList<Usuario>(), "Ha ocurrido un error", "106");
		try {
			int registrosActualizados = daoUsuario.delete(usuario);
			voUsuario
					.setMensaje(String.format("Se ha/n eliminado correctamente a %d usuario/s", registrosActualizados));
			voUsuario.setCodigo("0");
		} catch (Exception e) {
			logger.trace("Usuario Service: Error en delete", e);
		}
		return voUsuario;
	}

}
