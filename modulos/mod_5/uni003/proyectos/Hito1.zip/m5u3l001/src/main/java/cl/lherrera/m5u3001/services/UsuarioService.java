package cl.lherrera.m5u3001.services;


import cl.lherrera.m5u3001.models.Usuario;
import cl.lherrera.m5u3001.vo.UsuarioVO;

public interface UsuarioService {

	// por defectos son public abstract, es por esa razón que no hay problemas
	// con el alcance de paquetes, ya que en esta ocación no son por defecto seteados con
	// el modificador de paquetes.
	
	UsuarioVO obtenerTodosLosUsuarios();
	UsuarioVO obtenerUsuarioPorNombreYClave(String nombre, String clave);
	UsuarioVO login(String nombre, String clave);
	
	// para justificar el crud (Los servicios no son rígidos, se adaptan a la necesidad específica)
	// en este caso los métodos son con el mismo nombre que la implementación del DAO
	// pero es solamente a modo de ejemplo del ejercicio, ya que existe un UsuarioVO, enfocado a lo
	// que se muestra en pantalla es por eso que en el fondo el servicio llena esos
	// objetos, pero la implementación de los métodos de negocio van más allá que simplemente
	// retornar objetos tipo VO o DTOs.
	
	UsuarioVO add(Usuario usuario);
	UsuarioVO update(Usuario usuario);
	UsuarioVO delete(Usuario usuario);
}
