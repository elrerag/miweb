package cl.lherrera.m5u3001.services;
// ojo con los nombres de paquetes, mejor que sean iguales para no perder el contexto

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import cl.lherrera.m5u3001.models.Usuario;
import cl.lherrera.m5u3001.vo.UsuarioVO;

@SpringBootTest
@DisplayName("Prueba de servicios")
public class UsuarioServiceTest {
	private Logger logger = LoggerFactory.getLogger(UsuarioServiceTest.class.getName());
	
	@Autowired
	UsuarioService servicioUsuario;
	
	@Test
	@DisplayName("Prueba de servicio de login")	
	public void prueba001() {
		// capturar mensaje
		String mensaje = servicioUsuario.login("user1", "clave1").getMensaje();
		// comparar con respuesta
		assertTrue(mensaje.contains("Bienvenido"));
	}
	
	// Probamos CRUD
	
	// se agrega, se actualiza y se elimina el mismo dato, dejando la base de datos
	// de pruebas estable. (esta no debe ser una base de datos oficial
	
	@Test
	@DisplayName("Probar servicio add")
	public void prueba002() {
		// creamos un usuario
		Usuario usuario = new Usuario();
		usuario.setNombre("test1");
		usuario.setClave("clave1");
		// ingresamos el usuario con el servicio
		UsuarioVO respuesta = servicioUsuario.add(usuario);
		
		assertTrue(respuesta.getMensaje().contains("Se ha creado el usuario correctamente"));
		
	}
	
	@Test
	@DisplayName("Prueba servicio update")
	public void prueba003() {
		// llamamos al usuario
		UsuarioVO usuarioVo = servicioUsuario.obtenerUsuarioPorNombreYClave("test1", "clave1");
		Usuario usuario = usuarioVo.getUsuarios().get(0);
		// cambiamos un valor
		usuario.setNombre("test2");
		usuarioVo = servicioUsuario.update(usuario);
		
		// comprobamos con mensaje retornado del servicio
		assertTrue(usuarioVo.getMensaje().contains("actualizado correctamente"));
	}
	
	@Test
	@DisplayName("Prueba de eliminado")
	public void prueba004() {
		// se busca el usuario
		UsuarioVO usuarioVo = servicioUsuario.obtenerUsuarioPorNombreYClave("test2", "clave1");
		Usuario usuario = usuarioVo.getUsuarios().get(0);
		
		usuarioVo = servicioUsuario.delete(usuario);
		assertTrue(usuarioVo.getMensaje().contains("eliminado correctamente"));
	}
}
