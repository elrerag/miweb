package cl.lherrera.m5u3001;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M5u3001ApplicationTests {

	@Test
	void contextLoads() {
	}

}
