package cl.lherrera.m5u3001.daos;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import cl.lherrera.m5u3001.daos.UsuarioDAOImpl;
import cl.lherrera.m5u3001.models.Usuario;


@SpringBootTest
@DisplayName("Pruebas unitarias del DAO")
public class UsuarioDaoImplTest {
	
	@Autowired
	private UsuarioDAOImpl daoUsuario;
	
	
	@Test
	@DisplayName("Traer todos los usuarios")
	public void prueba001() {
		// guadamos en una lista los usuarios
		List<Usuario> usuarios = daoUsuario.getAllUsuarios();
		// deben existir 2 usuarios en la base de datos
		assertTrue(usuarios.size() >= 2);
	}
	
	@Test
	@DisplayName("traer al usuario user1 - clave1")
	public void prueba002() {
		// buscar el usuario con la clave y contraseña
		// este usuario debe estar en la base de datos
		Usuario usuario = daoUsuario.findByNombreAndClave("user1", "clave1");
		// comparamos con el nombre
		assertEquals("user1", usuario.getNombre());
	}
}
