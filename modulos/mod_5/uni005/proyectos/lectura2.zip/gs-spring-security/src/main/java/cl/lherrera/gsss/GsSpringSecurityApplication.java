package cl.lherrera.gsss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GsSpringSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(GsSpringSecurityApplication.class, args);
	}

}
