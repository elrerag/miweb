insert into users(email, password, role) values ('mail@fake.dev','$2y$12$x2/D0RmnpJFC0ZNbbDr6j.cPYFl9d/8hbNGFf8tQisA8AN47KGfqK','ROLE_USER'); 
insert into users(email, password, role) values ('mail2@fake.dev', '$2y$12$x2/D0RmnpJFC0ZNbbDr6j.cPYFl9d/8hbNGFf8tQisA8AN47KGfqK', 'ROLE_ADMIN');
