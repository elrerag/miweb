package cl.lherrera.gsss.model;

public enum Role {
	ROLE_ADMIN, ROLE_USER
}
