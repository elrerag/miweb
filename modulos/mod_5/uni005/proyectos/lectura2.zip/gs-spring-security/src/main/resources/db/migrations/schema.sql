DROP TABLE if exists users;
create table users(email varchar, password varchar, role varchar);