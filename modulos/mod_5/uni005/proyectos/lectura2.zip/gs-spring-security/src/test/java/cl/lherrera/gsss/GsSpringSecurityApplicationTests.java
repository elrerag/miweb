package cl.lherrera.gsss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GsSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
