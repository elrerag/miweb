package cl.lherrera.arriendopelis.dto;

public class GenericDTO {

	private String mensaje;
	private String codigo;

	public GenericDTO() {
		// TODO Auto-generated constructor stub
	}

	public GenericDTO(String mensaje, String codigo) {
		super();
		this.mensaje = mensaje;
		this.codigo = codigo;
	}

	public String getMensaje() {
		return mensaje;
	}

	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	@Override
	public String toString() {
		return "GenericDTO [mensaje=" + mensaje + ", codigo=" + codigo + "]";
	}

}
