package cl.lherrera.arriendopelis.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import cl.lherrera.arriendopelis.dto.ArriendoDTO;
import cl.lherrera.arriendopelis.modelo.Arriendo;
import cl.lherrera.arriendopelis.servicio.ArriendoService;
import cl.lherrera.arriendopelis.servicio.ClienteService;
import cl.lherrera.arriendopelis.servicio.PeliculaService;

@Controller
@RequestMapping(path = "/arriendos")
public class ArriendoController {

	@Autowired
	private ArriendoService arriendoService;

	@Autowired
	private PeliculaService peliculaService;

	@Autowired
	private ClienteService clienteService;

	@GetMapping(path = { "", "/" })
	public ModelAndView arriendos(Model model) {
		// se crea el modelAnd View, esto no solo renderiza la vista, si no que
		// envía el modelo.
		ModelAndView modelAndView = new ModelAndView("arriendos");

		modelAndView.addObject("arriendo", new Arriendo());
		model.addAttribute("peliculas", peliculaService.findAll().getPeliculas());
		model.addAttribute("clientes", clienteService.findAll().getClientes());
		return modelAndView;
	}

	/**
	 * @ModelAttribute es la anotación que permite acceder al modelo declarado en la
	 *                 vista que en este caso es arriendo.
	 */
	@PostMapping("/agregar")
	public RedirectView agregar(@ModelAttribute Arriendo arriendo) {
		ArriendoDTO respuestaServicio = arriendoService.add(arriendo);
		if (respuestaServicio.getCodigo().equals("0")) {
			return new RedirectView("/home");
		} else {
			return new RedirectView("/arriendos");
		}
	}

}
