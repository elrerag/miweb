package cl.lherrera.arriendopelis.servicio;

import cl.lherrera.arriendopelis.dto.ArriendoDTO;
import cl.lherrera.arriendopelis.modelo.Arriendo;

public interface ArriendoService {

	// acá el servicio usualmente difiere de la petición del dao
	// pero para efectos del ejemplo se llamará igual.
	// es tambíen una confisión común el no diferenciar entre
	// las responsablidades de los servicios y la de
	// los repositorios. Por eso es que los repositorios
	// se implementan automáticamente y los servicios
	// es la lógica de negocio que nosotros desarrollamos
	// usando lo autómático del repositorio. donde sabemos
	// como funciona un findAll(). La única justificación
	// es que el findAll del servicio, llenará un DTO; pero
	// debería ser otro nombre.
	ArriendoDTO findAll();

	ArriendoDTO add(Arriendo arriendo);

}
