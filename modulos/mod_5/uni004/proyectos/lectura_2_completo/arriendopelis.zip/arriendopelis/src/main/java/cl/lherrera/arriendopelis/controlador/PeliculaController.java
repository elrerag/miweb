package cl.lherrera.arriendopelis.controlador;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import cl.lherrera.arriendopelis.dto.PeliculaDTO;
import cl.lherrera.arriendopelis.modelo.Pelicula;
import cl.lherrera.arriendopelis.servicio.PeliculaService;

@Controller
@RequestMapping(path = "/peliculas")
public class PeliculaController {

	@Autowired
	private PeliculaService peliculaService;

	@GetMapping(path = { "", "/" })
	public ModelAndView peliculas() {
		ModelAndView modelAndView = new ModelAndView("peliculas");
		modelAndView.addObject("pelicula", new Pelicula());
		return modelAndView;
	}

	@PostMapping(path = "/agregar")
	public RedirectView agregar(@ModelAttribute Pelicula pelicula) {
		PeliculaDTO respuestaServicio = peliculaService.add(pelicula);
		if (respuestaServicio.getCodigo().equals("0")) {
			return new RedirectView("/home");
		} else {
			return new RedirectView("/peliculas");
		}
	}

}
