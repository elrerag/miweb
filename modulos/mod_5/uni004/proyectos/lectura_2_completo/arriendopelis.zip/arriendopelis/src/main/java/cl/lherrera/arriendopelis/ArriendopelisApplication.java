package cl.lherrera.arriendopelis;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Component;

import cl.lherrera.arriendopelis.modelo.Cliente;
import cl.lherrera.arriendopelis.modelo.Pelicula;
import cl.lherrera.arriendopelis.servicio.ClienteService;
import cl.lherrera.arriendopelis.servicio.PeliculaService;

@SpringBootApplication
public class ArriendopelisApplication {

	public static void main(String[] args) {
		SpringApplication.run(ArriendopelisApplication.class, args);
	}

}

/**
 * Esta clase, realiza acciones antes que la aplicación está en ejecución así,
 * el usuario está ingresado antes de iniciar sesión.
 *
 */
@Component
class SeEjecutaAntes implements CommandLineRunner {

	@Autowired
	ClienteService servicioCliente;

	@Autowired
	PeliculaService servicioPelicula;

	@Override
	public void run(String... args) throws Exception {

		Cliente cliente = new Cliente();
		cliente.setNombre("Luis");
		// se puede ver que add no es un buen nombre para un
		// servicio. Parece una lista.
		servicioCliente.add(cliente);

		Pelicula pelicula = new Pelicula();
		pelicula.setTitulo("El cubo");
		pelicula.setDescripcion("muy rara");
		pelicula.setDuracion(120);

		servicioPelicula.add(pelicula);

	}

}