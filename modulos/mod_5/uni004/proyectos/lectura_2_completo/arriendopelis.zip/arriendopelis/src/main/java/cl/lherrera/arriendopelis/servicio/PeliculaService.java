package cl.lherrera.arriendopelis.servicio;

import cl.lherrera.arriendopelis.dto.PeliculaDTO;
import cl.lherrera.arriendopelis.modelo.Pelicula;

public interface PeliculaService {
	PeliculaDTO findAll();

	PeliculaDTO add(Pelicula pelicula);
}
