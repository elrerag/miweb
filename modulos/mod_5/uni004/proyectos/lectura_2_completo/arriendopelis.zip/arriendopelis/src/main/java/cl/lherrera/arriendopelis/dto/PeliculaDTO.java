package cl.lherrera.arriendopelis.dto;

import java.util.List;

import cl.lherrera.arriendopelis.modelo.Pelicula;

public class PeliculaDTO extends GenericDTO {
	private List<Pelicula> peliculas;

	public PeliculaDTO() {
		// TODO Auto-generated constructor stub
	}

	public PeliculaDTO(String mensaje, String codigo) {
		super(mensaje, codigo);
		// TODO Auto-generated constructor stub
	}

	public PeliculaDTO(List<Pelicula> peliculas, String mensaje, String codigo) {
		super(mensaje, codigo);
		this.peliculas = peliculas;
	}

	public List<Pelicula> getPeliculas() {
		return peliculas;
	}

	public void setPeliculas(List<Pelicula> peliculas) {
		this.peliculas = peliculas;
	}

	@Override
	public String toString() {
		return "PeliculaDTO [peliculas=" + peliculas + "]";
	}

}
