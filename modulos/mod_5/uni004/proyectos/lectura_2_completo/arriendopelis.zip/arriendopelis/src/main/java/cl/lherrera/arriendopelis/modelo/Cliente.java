package cl.lherrera.arriendopelis.modelo;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Cliente {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	private String nombre;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "cliente")
	private List<Arriendo> arriendos;

	public Cliente() {
		// TODO Auto-generated constructor stub
	}

	public Cliente(Integer id, String nombre, List<Arriendo> arriendos) {
		super();
		this.id = id;
		this.nombre = nombre;
		this.arriendos = arriendos;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<Arriendo> getArriendos() {
		return arriendos;
	}

	public void setArriendos(List<Arriendo> arriendos) {
		this.arriendos = arriendos;
	}

	@Override
	public String toString() {
		return "Cliente [id=" + id + ", nombre=" + nombre + ", arriendos=" + arriendos + "]";
	}

}
