package cl.lherrera.arriendopelis.dto;

import java.util.List;

import cl.lherrera.arriendopelis.modelo.Arriendo;

public class ArriendoDTO extends GenericDTO {

	private List<Arriendo> arriendos;

	public ArriendoDTO() {
		// TODO Auto-generated constructor stub
	}

	public ArriendoDTO(List<Arriendo> arriendos) {
		super();
		this.arriendos = arriendos;
	}

	public ArriendoDTO(List<Arriendo> arriendos, String mensaje, String codigo) {
		super(mensaje, codigo);
		// TODO Auto-generated constructor stub
		this.arriendos = arriendos;
	}

	public List<Arriendo> getArriendos() {
		return arriendos;
	}

	public void setArriendos(List<Arriendo> arriendos) {
		this.arriendos = arriendos;
	}

	@Override
	public String toString() {
		return "ArriendoDTO [arriendos=" + arriendos + "]";
	}

}
