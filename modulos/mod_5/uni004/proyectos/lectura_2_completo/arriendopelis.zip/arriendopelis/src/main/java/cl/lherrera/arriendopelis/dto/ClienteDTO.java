package cl.lherrera.arriendopelis.dto;

import java.util.List;

import cl.lherrera.arriendopelis.modelo.Cliente;

public class ClienteDTO extends GenericDTO {

	private List<Cliente> clientes;

	public ClienteDTO() {
		// TODO Auto-generated constructor stub
	}

	public ClienteDTO(List<Cliente> clientes, String mensaje, String codigo) {
		super(mensaje, codigo);
		// TODO Auto-generated constructor stub
		this.clientes = clientes;
	}

	public List<Cliente> getClientes() {
		return clientes;
	}

	public void setClientes(List<Cliente> clientes) {
		this.clientes = clientes;
	}

	@Override
	public String toString() {
		return "ClienteDTO [clientes=" + clientes + "]";
	}
}
