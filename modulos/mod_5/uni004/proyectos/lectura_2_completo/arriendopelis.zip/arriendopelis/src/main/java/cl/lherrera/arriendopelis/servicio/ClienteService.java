package cl.lherrera.arriendopelis.servicio;

import cl.lherrera.arriendopelis.dto.ClienteDTO;
import cl.lherrera.arriendopelis.modelo.Cliente;

public interface ClienteService {
	ClienteDTO findAll();

	ClienteDTO add(Cliente cliente);
}
