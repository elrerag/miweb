package cl.lherrera.arriendopelis.dao;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import cl.lherrera.arriendopelis.modelo.Arriendo;
import cl.lherrera.arriendopelis.modelo.Cliente;
import cl.lherrera.arriendopelis.modelo.Pelicula;

@SpringBootTest
public class ClienteRepositoryTest {

	@Autowired
	private ArriendoRepository arriendoRepository;

	@Autowired
	private ClienteRepository clienteRepository;

	@Test
	public void validandoDatos() {
		// Instanciamos las tres clases.
		Pelicula pelicula = new Pelicula();
		Cliente cliente = new Cliente();
		Arriendo arriendo = new Arriendo();
		// Guardamos al cliente en base de datos para generar su ID.
		// cliente.setNombre("Juan");
		cliente = clienteRepository.save(cliente);
		// Asignamos un estado a la pelicula
		pelicula.setDescripcion("Buena pelicula");
		pelicula.setDuracion(160);
		pelicula.setTitulo("El cuadro");
		// Asignamos un estado al arriendo
		arriendo.setDuracion(10);
		arriendo.setInicio("11/12/2019");
		arriendo.setPelicula(pelicula);
		// Le asignamos al cliente previamente creado.
		arriendo.setCliente(cliente);
		// Guardamos la pelicula y el arriendo
		arriendo = arriendoRepository.save(arriendo);
		// Creamos una lista de arriendos y agregamos el que ya creamos a ella.
		List<Arriendo> arriendos = new ArrayList<>();
		arriendos.add(arriendo);
		cliente.setArriendos(arriendos);
		// Guardamos al cliente en base de datos
		cliente = clienteRepository.save(cliente);
		// afirmaciones
		assertThat(arriendoRepository.findAll()).isNotNull();
		assertThat(clienteRepository.findAll()).isNotNull();
	}

}
