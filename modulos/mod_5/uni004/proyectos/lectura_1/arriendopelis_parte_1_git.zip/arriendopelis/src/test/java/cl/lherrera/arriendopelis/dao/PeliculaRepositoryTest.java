package cl.lherrera.arriendopelis.dao;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import cl.lherrera.arriendopelis.modelo.Arriendo;
import cl.lherrera.arriendopelis.modelo.Pelicula;

@SpringBootTest
public class PeliculaRepositoryTest {

	@Autowired
	private ArriendoRepository arriendoRepository;
	@Autowired
	PeliculaRepository peliculaRepository;

	// este test fallará con la aplicación de la última relación Se comenta para que 
	// se ejecute sin problemas el siguiente.
	// esto se debe a que se agrega un campo a la relación.
//	@Test
//	public void validaRepositoriosCreandoPeliculaYArriendo() {
//		// nueva pelicula
//		Pelicula spaceOdyssey = new Pelicula(null, "2001: A Space Odyssey",
//				"After discovering a mysterious artifact buried " + "beneath the Lunar surface, mankind sets off on a "
//						+ "quest to find its origins with help from intelligent " + "supercomputer H.A.L. 9000. ",
//				149);
//
//		// nuevo arriendo
//		Arriendo arriendo = new Arriendo(null, "11/20/2019", 7, spaceOdyssey);
//		// guardar arriendo
//		arriendoRepository.save(arriendo);
//		// buscar arriendo
//		Arriendo arriendoOd = arriendoRepository.findById(1).get();
//		// valida que exista
//		assertThat(arriendoOd).isNotNull();
//
//	}
	
}
