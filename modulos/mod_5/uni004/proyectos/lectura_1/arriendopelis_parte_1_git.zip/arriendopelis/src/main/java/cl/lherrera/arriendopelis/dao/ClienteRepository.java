package cl.lherrera.arriendopelis.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.lherrera.arriendopelis.modelo.Cliente;

public interface ClienteRepository extends JpaRepository<Cliente, Integer> {

}
