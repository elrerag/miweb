package cl.lherrera.arriendopelis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ArriendopelisApplicationTests {

	@Test
	void contextLoads() {
	}

}
