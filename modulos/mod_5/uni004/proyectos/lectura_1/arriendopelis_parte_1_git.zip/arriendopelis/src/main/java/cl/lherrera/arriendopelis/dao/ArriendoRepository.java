package cl.lherrera.arriendopelis.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.lherrera.arriendopelis.modelo.Arriendo;

public interface ArriendoRepository extends JpaRepository<Arriendo, Integer> {

}
