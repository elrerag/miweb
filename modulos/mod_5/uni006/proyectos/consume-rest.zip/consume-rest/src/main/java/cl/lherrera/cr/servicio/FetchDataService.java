package cl.lherrera.cr.servicio;

import cl.lherrera.cr.modelo.Quote;

public interface FetchDataService {
	
	Quote fetchQuote();

}
