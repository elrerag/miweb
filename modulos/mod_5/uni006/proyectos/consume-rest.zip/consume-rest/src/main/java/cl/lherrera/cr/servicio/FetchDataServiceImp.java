package cl.lherrera.cr.servicio;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import cl.lherrera.cr.modelo.Quote;

@Service
public class FetchDataServiceImp implements FetchDataService {
	
	@Value("${endpoints.quote}") 
	private String quoteEndpoint;
	
	private RestTemplate restTemplate;

	/**
	 * https://stackoverflow.com/questions/40620000/spring-autowire-on-properties-vs-constructor 
	 */
	@Autowired
	public FetchDataServiceImp(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	@Override
	public Quote fetchQuote() {
		return restTemplate.getForObject(quoteEndpoint, Quote.class);
	}

}
