package cl.lherrera.pr;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProduceRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
