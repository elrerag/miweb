package cl.lherrera.pr.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

	@Autowired
	private JwtTokenProvider jwtTokenProvider;

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		// sin verificación csrf, inseguro. (Laravel)
		http.csrf().disable();

		// sesión sin estado.
		http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		
		// Autorización de peticiones
		http.authorizeRequests()
			// para los paths -> autorizar todo
			.antMatchers("/api/v1/users/signin").permitAll()
			// para los paths -> autorizar todo
			.antMatchers("/api/v1/users/signup").permitAll()
			// para todo lo demás, acceso solamente con
			// autentificación.
			.anyRequest().authenticated();
		
		// en caso que ocurra una excepción de págiina
		// denegada por error de credenciales
		// personalizamos el servicio a ejecutar.
		// que en este caso nos lleva a la 
		// web de login.
		http.exceptionHandling().accessDeniedPage("/login");
		
		// Applies a {@link SecurityConfigurer} to this {@link SecurityBuilder} overriding any
		// {@link SecurityConfigurer} of the exact same class. Note that object hierarchies
		// are not considered.
		// 
		// 
		// El filtro personaliizado que creamos en JwtTokenFilterConfigurer, donde
		// validamos el token, y si es válido crea el Authenticate, se aplica acá
		// es un filtro que se concatena a los que ya hemos puesto en este mismo
		// método, se aplica antes que a todos por que JwtTokenFilterConfigurer
		// HttpSecurity.addFilterBefore(customFilter, UsernamePasswordAuthenticationFilter.class);
		// le decimos que el filtro lo realice antes que se ejecute la autenticación con
		// user y password.
		http.apply(new JwtTokenFilterConfigurer(jwtTokenProvider) );
	}

	@Bean
	@Override
	public AuthenticationManager authenticationManagerBean() throws Exception {
		return super.authenticationManagerBean();
	}

	@Bean
	public PasswordEncoder passwordEncoder() {
		// fuerza = 12 (entre 4 y 31)
		return new BCryptPasswordEncoder(12);
	}
}