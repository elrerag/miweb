package cl.lherrera.pr.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import cl.lherrera.pr.dto.UserDTO;
import cl.lherrera.pr.servicio.UserService;

@RestController
@RequestMapping("/api/v1/users")
public class UserController {
	@Autowired
	private UserService userService;

	/**
	 * Método encargado de hacer el login, ocupa el servicio signin.
	 */
	@PostMapping("/signin")
	public String login(@RequestParam String username, @RequestParam String password) {
		return userService.signin(username, password);
	}

	/**
	 * Registra un usuario, Realiza la tarea de ingreso.
	 */
	@PostMapping("/signup")
	@ResponseStatus(HttpStatus.CREATED)
	public String signup(@RequestBody UserDTO userDTO) {
		return userService.signup(userDTO);
	}

	/**
	 * Por defecto, la petición entrega una lista de los usuarios.
	 */
	@GetMapping(path = { "", "/" })
	@ResponseStatus(code = HttpStatus.OK)
	public List<UserDTO> findAll() {
		return userService.encontrarTodos();
	}

	/**
	 * Encuentra un usuario por ID, es un servicio para cuando se necesite un
	 * usuario en particular.
	 */
	@GetMapping(path = "/{id}")
	@ResponseStatus(code = HttpStatus.OK)
	public UserDTO findOne(@PathVariable Long id) {
		return userService.encontrarPorId(id);
	}

	/**
	 * Servicio destinado a actualizar los datos de un usuario.
	 */
	@PutMapping(path = { "", "/" })
	@ResponseStatus(HttpStatus.OK)
	void update(@RequestBody UserDTO userDTO) {
		userService.actualizar(userDTO);
	}

	/**
	 * Servicio destinado a eliminar a un usuario.
	 */
	@DeleteMapping
	@ResponseStatus(HttpStatus.OK)
	void delete(@RequestBody UserDTO userDTO) {
		userService.eliminar(userDTO);
	}
}