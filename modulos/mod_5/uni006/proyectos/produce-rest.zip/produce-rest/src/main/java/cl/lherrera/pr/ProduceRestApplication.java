package cl.lherrera.pr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProduceRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProduceRestApplication.class, args);
	}

}
