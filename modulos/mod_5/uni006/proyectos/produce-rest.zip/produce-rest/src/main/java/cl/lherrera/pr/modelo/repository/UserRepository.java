package cl.lherrera.pr.modelo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.lherrera.pr.modelo.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
	// necesario para la autenticación
	boolean existsByUsername(String username);

	User findByUsername(String username);
}
