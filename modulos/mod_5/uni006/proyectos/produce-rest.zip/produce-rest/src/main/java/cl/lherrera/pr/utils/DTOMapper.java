package cl.lherrera.pr.utils;

import cl.lherrera.pr.dto.UserDTO;
import cl.lherrera.pr.modelo.entity.User;

public class DTOMapper {
	private DTOMapper() {
	}

	private static void toEntity(UserDTO userDTO, User user) {
		user.setId(userDTO.getId());
		user.setName(userDTO.getName());
		user.setUsername(userDTO.getUsername());
		user.setEmail(userDTO.getEmail());
		user.setPassword(userDTO.getPassword());
		user.setRoles(userDTO.getRoles());
	}

	public static User toEntity(UserDTO userDTO) {
		User user = new User();
		toEntity(userDTO, user);
		return user;
	}

	public static UserDTO toDTO(User user) {
		UserDTO userDTO = new UserDTO();
		userDTO.setId(user.getId());
		userDTO.setName(user.getName());
		userDTO.setUsername(user.getUsername());
		userDTO.setEmail(user.getEmail());
		userDTO.setPassword(null);
		userDTO.setRoles(user.getRoles());
		return userDTO;
	}
}
