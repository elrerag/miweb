package cl.lherrera.pr.security;

import java.util.Base64;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import cl.lherrera.pr.exception.RestServiceException;
import cl.lherrera.pr.modelo.entity.Role;
import cl.lherrera.pr.servicio.UserService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Component
public class JwtTokenProvider {
	private Logger logger = LoggerFactory.getLogger(JwtTokenProvider.class);

	// propiedad
	@Value("${security.jwt.token.secret-key}")
	private String secretKey;

	// propiedad
	@Value("${security.jwt.token.expire-length}")
	private long validityInMilliseconds;

	// servicio Implementado
	@Autowired
	private UserService userService;

	/**
	 * Spring calls methods annotated with @PostConstruct
	 * only once, just after the initialization 
	 * of bean properties.
	 * https://www.baeldung.com/spring-postconstruct-predestroy
	 * 
	 * Asigna el valor de la clave secreta
	 */
	@PostConstruct
	protected void init() {
		secretKey = Base64.getEncoder().encodeToString(secretKey.getBytes());
		logger.debug("LLave inicializada: " + secretKey);
	}

	public String createToken(String username, List<Role> roles) {
		Claims claims = Jwts.claims().setSubject(username);
		
		List<SimpleGrantedAuthority> grats = roles.stream()
				.map(rol -> new SimpleGrantedAuthority(rol.getAuthority()) )
				.filter(Objects::nonNull)
				.collect(Collectors.toList());
		
		claims.put("auth", grats);
		
		// expiración del token
		Date now = new Date();
		Date validity = new Date(now.getTime() + validityInMilliseconds);
		
		// creación del token
		String token = Jwts.builder()
			.setClaims(claims)
			.setIssuedAt(now)
			.setExpiration(validity)
			.signWith(SignatureAlgorithm.HS256, secretKey)
			.compact(); 
		
		return token;
	}

	/**
	 * A partir del token se obtiene el nombre de usuario y luego, 
	 * se obtiene un `UserDetails`, que ya sabemos que es la 
	 * entidad que maneja como ususuario de sesión.
	 */
	public Authentication getAuthentication(String token) {
		UserDetails userDetails = userService.loadUserByUsername(getUsername(token));
		UsernamePasswordAuthenticationToken autenticacion;
		autenticacion = new UsernamePasswordAuthenticationToken(
				userDetails, 
				"", 
				userDetails.getAuthorities()
		);
		
		return autenticacion;
	}

	private String getUsername(String token) {
		String userName = Jwts.parser()
				.setSigningKey(secretKey)
				.parseClaimsJws(token)
				.getBody()
				.getSubject();

	return userName;

	}

	/**
	 * Quitamos "Bearer " del principio del token
	 */
	public String resolveToken(HttpServletRequest req) {
		String bearerToken = req.getHeader("Authorization");
		if (bearerToken != null && bearerToken.startsWith("Bearer ")) {
			return bearerToken.substring(7);
		}
		return null;
	}

	/**
	 * Si el token logra ser parseado, entonces se asume que es un
	 * Token válido. `parseClaimsJws` analiza la llave (no un 
	 * token que exista hipoteticamente, la comparación se 
	 * realiza entre el token que está en el request
	 * y la clave cifrada de esta clase. cifrada
	 * justo después de construirse este
	 * objeto `INIT`).
	 */
	public boolean validateToken(String token) {
		try {
			Jwts.parser().setSigningKey(secretKey).parseClaimsJws(token);
			return true;
		} catch (JwtException | IllegalArgumentException e) {

			throw new RestServiceException(
				"Expired or invalid JWT token", 
				HttpStatus.INTERNAL_SERVER_ERROR
			);
		}
	}
}
