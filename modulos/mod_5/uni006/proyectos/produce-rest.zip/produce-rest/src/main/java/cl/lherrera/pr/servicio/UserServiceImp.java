package cl.lherrera.pr.servicio;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import cl.lherrera.pr.dto.UserDTO;
import cl.lherrera.pr.modelo.entity.User;
import cl.lherrera.pr.modelo.repository.UserRepository;
import cl.lherrera.pr.security.JwtTokenProvider;
import cl.lherrera.pr.utils.DTOMapper;

import cl.lherrera.pr.exception.RestServiceException;

@Service
public class UserServiceImp implements UserService, UserDetailsService {

	@Autowired
	UserRepository repoUsuario;

	// sección de seguridad
	@Autowired
	private PasswordEncoder passwordEncoder;

	@Autowired
	private JwtTokenProvider jwtTokenProvider;

	@Autowired
	private AuthenticationManager authenticationManager;
	// sección de seguridad #

	@Override
	public void actualizar(UserDTO user) {
		repoUsuario.save(DTOMapper.toEntity(user));
	}

	@Override
	public List<UserDTO> encontrarTodos() {
		// cada elemento de la lista deberá ser
		// convertido en su dto.
		return repoUsuario.findAll().stream().map(usuario -> DTOMapper.toDTO(usuario)).collect(Collectors.toList());

	}

	@Override
	public UserDTO encontrarPorId(Long id) {
		User usuario = repoUsuario.findById(id).orElse(null);
		// TODO Auto-generated method stub
		return DTOMapper.toDTO(usuario);
	}

	@Override
	public void eliminar(UserDTO user) {
		User usuario = DTOMapper.toEntity(user);
		repoUsuario.delete(usuario);
	}

	/**
	 * Inicia la sesión, retornando un token en caso que sea exitoso o
	 * retornando una exeption en caso de no ser exitoso.
	 * 
	 * La técnica es fabricar un objeto que implemente Authentication, en este caso
	 * UsernamePasswordAuthenticationToken, una de sus implementaciones y la que
	 * usaremos acá. Esta implementación requiere dos parámetros, un principal
	 * que para nuestro caso es el username, y un credentials que es la
	 * contraseña. Posee un tercer parámetro que no vemos y este es
	 * setAutenticated(false). Es decir que se crea un objeto tipo
	 * Authentication, con tres parámetros:
	 * - principal: username
	 * - credentials: password
	 * - setAuthenticated(false)
	 * 
	 * Este objeto es pasado a authenticationManager.authenticate(), y pueden pasar 2 cosas.
	 * La primera es que se logre hacer el inicio de sesión y siga la ejecución y la otra
	 * es que no se pueda realizar la autenticación y se arroje un AuthenticationException
	 * lo que hará que no se genere el token por que no se sigue ejecutando la aplicación
	 * en ese contexto.
	 * 
	 * La generación del token es independiente a si se pudo o no iniciar sesión. Esta
	 * generación se puede realizar con un usuario que no esté autenticado. Pero en el
	 * ejemplo, como se arroja una excepción no se continúa con la ejecución y es por
	 * este motivo que no llega a generarse el token.
	 * 
	 * El intento de inicio de sesión es interno, se deduce de los parámetros que
	 * tenga asignados en la configuración de los parámetros que se mapean en la
	 * base de datos, en este caso, tenemos que en la tabla user, hay un campo
	 * username y un campo password, que este `authenticate` comparará con los campos
	 * principal y credentials que en este caso son los `raw_username y raw_password`
	 * aunque solamente en la base de datos esté la contraseña encriptada, el método
	 * `authenticate` sabe como realizar una operación que indique que el `raw_password`
	 * sea matemáticamente equivalente con nuestra contraseña en la base de datos.
	 * 
	 */
	@Override
	public String signin(String username, String password) {
		String token = "";
		try {
			// llenamos el objeto de autenticación. en este caso se crea por defecto
			// con setAutenticated en falso. Setear esto en verdadero, es tarea de
			// authenticationManager, que al no poder realizar el match, arroja
			// un AuthenticationException. si no se retorna el token.
			Authentication objetoAutentificacion = new UsernamePasswordAuthenticationToken(username, password);
			// le decimos al administrador de authenticacion, que intente autenticar con el usuario dado.
			// si esto no es posible, en este punto se arroja una excepción. y nada más se ejecuta.
			authenticationManager.authenticate(objetoAutentificacion);
			
			User usuarioAutenticado = repoUsuario.findByUsername(username);
			// solamente si el usuario pasa la existencia correcta de sus credenciiales
			// llegaremos hasta este punto, es decir que el token no juega 
			// ningún papel en la validación de usuario, todo lo que puede
			// validar es un token.
			token = generaToken(usuarioAutenticado);

		} catch (AuthenticationException e) {
			throw new RestServiceException("username o password invalido", HttpStatus.UNPROCESSABLE_ENTITY);
		}
		
		return token;
	}

	/**
	 * Registro de usuario en el sistema, ingresa un nuevo usuario en la base
	 * de datos. Retorna el token para poder comenzar con las peticioines.
	 * Quizás no sea una buena manera, quizás el token, solamente debería
	 * ser entregado al momento de hacer un inicio de sesión; perso
	 * así está implementado en el ejemplo.
	 */
	@Override
	public String signup(UserDTO user) {
		String jwtToken = "";
		boolean existeUsuario = repoUsuario.existsByUsername(user.getUsername());
		
		if (!existeUsuario) {
			User usuario = registraUsuario(user);
			jwtToken = generaToken(usuario);
		} else {
			String message = "Username ya está en uso";
			HttpStatus httpStatus = HttpStatus.UNPROCESSABLE_ENTITY;
			throw new RestServiceException(message, httpStatus);
		}

		return jwtToken;
	}

    /**
    * Construye un `UserDetails` estático, con la información que se le proporcione.
    * En este caso, el nombre de usuario que venía como argumento y
    * la contraseña que está en la base de datos. Este proceso
    * es implementado ya que este único método, posee
    * acceso a la contraseña del usuario.
    *
    * La técnica usada es que cada método retorna un `UserBuilder`, hasta
    * llegar a `build()`, es cuando finalmente es convertido en
    * un `UserDetail`. 
    *
    **/
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		final User user = repoUsuario.findByUsername(username);
		if (user == null) {
			throw new UsernameNotFoundException("Usuario '" + username + "' no encontrado");
		}
		return org.springframework.security.core.userdetails.User//
				.withUsername(username).password(user.getPassword()).authorities(user.getRoles()).accountExpired(false)
				.accountLocked(false).credentialsExpired(false).disabled(false).build();
	}
	
	/**
	 * Executa el ingreso de un usuario al sistema. 
	 */
	private User registraUsuario(UserDTO userDto) {
		String rawPassword = userDto.getPassword();
		
		// uso de la referencia al objeto passwordEncoder
		// posee un método encode que implementa Spring
		// que toma el rawPassword y lo encripta.
		String contraseniaEncriptada = passwordEncoder.encode(rawPassword);			
		userDto.setPassword(contraseniaEncriptada);
		User usuario = DTOMapper.toEntity(userDto);
		repoUsuario.save(usuario);
		
		return usuario;
	}
	
	/**
	 * Genera el token, usando el nombre de usuario y los
	 * roles. (Usamos el usuario aunque se puede con
	 * un usuarioDTO).
	 */
	private String generaToken(User usuario) {
		String token = jwtTokenProvider.createToken(
		    usuario.getUsername(),
		    usuario.getRoles()
		);

		return token;
	}

}
