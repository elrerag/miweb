package cl.lherrera.pr.servicio;

import java.util.List;

import org.springframework.security.core.userdetails.UserDetails;

import cl.lherrera.pr.dto.UserDTO;

public interface UserService {

	void actualizar(UserDTO user);

	List<UserDTO> encontrarTodos();

	UserDTO encontrarPorId(Long id);

	void eliminar(UserDTO user);

	// usados para las credenciales.
	String signin(String username, String password);

	// nuestro nuevo ingresar
	String signup(UserDTO user);

	UserDetails loadUserByUsername(String username);

}
